import random as r
import sys as s

class Karaktar:
    def __init__(self,namn,ERF):
        self.namn = namn
        self.ERF = ERF
        self.ERFkvar = ERF
        self.Karaktarsdrag = self.skapaKaraktarsdrag()
        self.Formagor = {}
        self.formagAlternativ = self.gynnsammaFormagor()
        self.valjNyaFormagor(ERF)

        print('Välkommen till äventryret '+self.namn+'!')
        print('Dina karaktärsdrag är:')
        for drag in list(self.Karaktarsdrag):
            print(drag.ljust(11)+str(self.Karaktarsdrag[drag]).rjust(5))
        print('')
        print('Dina första förmågor är:')
        for formaga in list(self.Formagor):
            print(formaga.ljust(28)+str(self.Formagor[formaga]).rjust(10))
        print('')

        """
        lägg till funciton som skapar textfil och som kan kallas på för att uppdatera
        """

        self.sparaKaraktar()

    def skapaKaraktarsdrag(self):
        Karaktarsdrag = {
        'Diskret':5,
        'Kvick':5,
        'Listig':5,
        'Stark':5,
        'Träffsäker':5,
        'Vaksam':5,
        'Viljestark':5,
        'Övertygande':5
        }
        for i in range(40):
            roll = 'not done'
            while roll != 'done':
                T8 = r.randrange(0,8)
                drag = list(Karaktarsdrag)[T8]
                if Karaktarsdrag[drag] == 15:
                    roll = 'not done'
                elif Karaktarsdrag[drag] == 14:
                    max = 'not reached'
                    for dragen in Karaktarsdrag:
                        if Karaktarsdrag[dragen] == 15:
                            max = 'reached'
                    if max == 'reached':
                        roll = 'not done'
                    else:
                        Karaktarsdrag[drag] += 1
                        roll = 'done'
                else:
                    Karaktarsdrag[drag] += 1
                    roll = 'done'
        return Karaktarsdrag # Skapar karaktärsdragen

    def visaKaraktarsdrag(self):
        for drag in list(self.Karaktarsdrag):
            print(drag+' '+str(self.Karaktarsdrag[drag]))

    def valjNyaFormagor(self,ERF):
        ERFkvar = ERF
        Karaktarsdrag = self.Karaktarsdrag
        alt = self.formagAlternativ
        while ERFkvar >= 10:
            span = len(alt)
            v = r.randrange(0,span)
            val = alt[v]
            if val in self.Formagor:
                niva = self.Formagor[val]
                if niva == 'Gesäll':
                    if ERFkvar >= 30:
                        self.Formagor[val] = 'Mästare'
                        uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                        self.formagAlternativ = uppdateradeAlternativ
                        uppdateradeAlternativ = [value for value in alt if value != val]
                        alt = uppdateradeAlternativ
                        ERFkvar = ERFkvar - 30
                    else:
                        uppdateradeAlternativ = [value for value in alt if value != val]
                        alt = uppdateradeAlternativ
                else:
                    if ERFkvar >= 20:
                        self.Formagor[val] = 'Gesäll'
                        ERFkvar = ERFkvar - 20
                    else:
                        uppdateradeAlternativ = [value for value in alt if value != val]
                        alt = uppdateradeAlternativ
            else:
                self.Formagor[val] = 'Novis'
                ERFkvar = ERFkvar - 10
        self.ERFkvar = ERFkvar




            # Kolla alternativ 1


            # Kolla alternativ 2

            # Kolla altenativ 3

    def gynnsammaFormagor(self):
        Diskret = ['Fint','Lönnstöt']
        Kvick = ['Akrobatik','Snabbdrag']
        Listig = ['Alkemi','Giftbrukare','Lärd','Medicus','Monsterlärd',
        'Stryparkonst','Taktiker']
        Stark = ['Järnnäve','Sköldkamp','Ståndaktig']
        Traffsaker = ['Naturlig krigare','Prickskytt']
        Vaksam = ['Häxsyn','Sjätte sinne']
        Viljestark = ['Häxkonster','Häxsyn','Livvakt','Mystisk kraft',
        'Ordensmagi','Ritualist','Ståndaktig','Svartkonst','Teurgi',
        'Återhämtning']
        # Hur lösa de med magi?
        Overtygande = ['Dominera','Ledare']
        Allmann = ['Bärsärk','Exceptionellt Karaktärsdrag','Rustmästare',
        'Ryttarkonst','Stångverkan','Stålkast','Tvillingattack','Tvåhandskraft']

        Formagor = [Diskret,Kvick,Listig,Stark,Traffsaker,Vaksam,Viljestark,Overtygande,Allmann]

        alternativ1 = []
        i = -1
        for drag in list(self.Karaktarsdrag):
            i += 1
            if self.Karaktarsdrag[drag] == 15:
                for j in range(len(Formagor[i])):
                    alternativ1.append(Formagor[i][j])

        alternativ2 = []
        i = -1
        for drag in list(self.Karaktarsdrag):
            i += 1
            if self.Karaktarsdrag[drag] > 12 and self.Karaktarsdrag[drag] != 15:
                for j in range(len(Formagor[i])):
                    alternativ2.append(Formagor[i][j])

        alternativ3 = []
        i = -1
        for drag in list(self.Karaktarsdrag):
            i += 1
            if self.Karaktarsdrag[drag] > 10 and self.Karaktarsdrag[drag] < 13:
                for j in range(len(Formagor[i])):
                    alternativ3.append(Formagor[i][j])
        for formaga in Allmann:
            alternativ3.append(formaga)

        Alternativ = []
        for formaga in alternativ1:
            Alternativ.append(formaga)
            Alternativ.append(formaga)
            Alternativ.append(formaga)
            Alternativ.append(formaga)
        for formaga in alternativ2:
            Alternativ.append(formaga)
            Alternativ.append(formaga)
        for formaga in alternativ3:
            Alternativ.append(formaga)

        return Alternativ

    def levla(self,ERF):
        ERFtotal = ERF + self.ERFkvar
        self.valjNyaFormagor(ERFtotal)

        print('Dina förmågor är nu:')
        for formaga in list(self.Formagor):
            print(formaga.ljust(28)+str(self.Formagor[formaga]).rjust(10))

        self.sparaKaraktar()

    def sparaKaraktar(self):
        f = open(self.namn+'.txt', "w")
        f.write('Karaktär: '+self.namn+
        '\n'+'\n'+
        'Karaktärsdrag:'
        +'\n')
        f.close()

        for drag in list(self.Karaktarsdrag):
            f = open(self.namn+'.txt', "a")
            f.write(drag.ljust(11)+str(self.Karaktarsdrag[drag]).rjust(5)
            +'\n')
            f.close()

        f = open(self.namn+'.txt', "a")
        f.write('\n'+'Förmågor: '+
        '\n')
        f.close()

        for formaga in list(self.Formagor):
            f = open(self.namn+'.txt', "a")
            f.write(formaga.ljust(28)+str(self.Formagor[formaga]).rjust(10)
            +'\n')
            f.close()


#------------------------------------------------------------------------------#

Bob = Karaktar(s.argv[1],int(s.argv[2]))
#Bob.levla(30)
