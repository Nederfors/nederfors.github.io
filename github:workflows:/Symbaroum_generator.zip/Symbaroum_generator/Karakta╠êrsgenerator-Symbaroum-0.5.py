"""
Hej och välkommen!

Med denna kod kan du skapa en slumpmässig rollspelskaraktär. En del information
får du direkt printad när koden körs men för all information om karaktären får du
titta i textdokumentet som koden skapar (dokumentet hittar du i samma mapp som
python-filen ligger i). Viktigt för att koden ska funka är att denna fil ligger
i samma mapp som "SymbaroumGenerator".

För att skapa en karaktär skriver du följande:

'namn på karaktär' = Karaktär('namn',startERF,dragTyp,formagTyp)

namn = Namnet på karaktären
startERF = Den mängd erfarenhetspoäng som karaktären ska börja med
dragTyp = Påverkar val av karaktärsdrag, kan ta emot tre olika alternativ:
    - 'specialist' = Skapar en karaktär med 15 i ett karaktärsdrag och fördelar
    slumpmässigt ut resterande poäng
    - 'minmax' = Skapar en karaktär med 15 och 14 i så många karaktärsdrag som
    möjligt på måfå
    - Lämnas det tomt eller skrivs något annat så fördelas poäng ut helt på måfå
formagTyp = Påverkar val av förmågor, kan ta emot två alternativ:
    - 'Mästare' = Skapar karaktär som i största möjliga mån väljer att gå till
    mästarnivå i förmågor den väljer. När ERF inte räcker väljs istället gesäll
    och därefter novis
    - Lämnas det tomt eller skrivs något annat så väljs förmågor helt på måfå

För att lämna ett område tomt skriv: ''

"""
#------------------------------------------------------------------------------#
# Rör inte detta!!!
import SymbaroumGenerator as S

#------------------------------------------------------------------------------#
# Fält för dig att skriva i!

Bob1 = S.Karaktar('Bob1',100,'','')
#Bob2 = Karaktar('Bob2',100,'','')


#------------------------------------------------------------------------------#
import random as r

class Karaktar:
    def __init__(self,namn,ERF,dragTyp,formagTyp):
        self.namn = namn
        self.ERF = ERF
        self.ERFkvar = ERF
        self.Karaktarsdrag = self.skapaKaraktarsdrag(dragTyp)
        stats = self.ovrigaStats()
        self.maximalTalighet = stats[0]
        self.smartgrans = stats[1]
        self.korruptionstroskel = stats[2]
        self.permanentKorruption = stats[3]
        self.Formagor = {}
        self.formagAlternativ = self.gynnsammaFormagor()
        self.krafter = []
        self.ritualer = []
        self.valdaRitualer = []
        self.tradition = ''
        self.allaKrafter = []
        self.allaRitualer = []
        self.mojligaKrafterOchRitualer('ingen')
        self.valjNyaFormagor(ERF,formagTyp)

        print('Välkommen till äventryret '+self.namn+'!')
        print('Dina karaktärsdrag är:')
        for drag in list(self.Karaktarsdrag):
            print(drag.ljust(11)+str(self.Karaktarsdrag[drag]).rjust(5))
        print('')
        print('Dina första förmågor är:')
        for formaga in list(self.Formagor):
            print(formaga.ljust(28)+str(self.Formagor[formaga]).rjust(10))
        print('')

        self.sparaKaraktar()

    def skapaKaraktarsdrag(self,typ):
        Karaktarsdrag = {
        'Diskret':5,
        'Kvick':5,
        'Listig':5,
        'Stark':5,
        'Träffsäker':5,
        'Vaksam':5,
        'Viljestark':5,
        'Övertygande':5
        }

        if typ == 'specialist':
            T8 = r.randrange(0,8)
            Drag = list(Karaktarsdrag)
            drag = Drag[T8]
            Karaktarsdrag[drag] = 15
            Drag.remove(drag)
            for i in range(30):
                roll = 'not done'
                while roll != 'done':
                    T7 = r.randrange(0,7)
                    drag = Drag[T7]
                    if Karaktarsdrag[drag] == 14:
                        roll = 'not done'
                    else:
                        Karaktarsdrag[drag] += 1
                        roll = 'done'
        elif typ == 'minmax':
            T8 = r.randrange(0,8)
            Drag = list(Karaktarsdrag)
            drag = Drag[T8]
            Karaktarsdrag[drag] = 15
            Drag.remove(drag)
            for i in range(3):
                Ti = r.randrange(0,7-i)
                drag = Drag[Ti]
                Karaktarsdrag[drag] = 14
                Drag.remove(drag)
            T4 = r.randrange(0,4)
            drag = Drag[T4]
            Karaktarsdrag[drag] = 8
        else:
            for i in range(40):
                roll = 'not done'
                while roll != 'done':
                    T8 = r.randrange(0,8)
                    drag = list(Karaktarsdrag)[T8]
                    if Karaktarsdrag[drag] == 15:
                        roll = 'not done'
                    elif Karaktarsdrag[drag] == 14:
                        max = 'not reached'
                        for dragen in Karaktarsdrag:
                            if Karaktarsdrag[dragen] == 15:
                                max = 'reached'
                        if max == 'reached':
                            roll = 'not done'
                        else:
                            Karaktarsdrag[drag] += 1
                            roll = 'done'
                    else:
                        Karaktarsdrag[drag] += 1
                        roll = 'done'
        return Karaktarsdrag # Skapar karaktärsdragen

    def ovrigaStats(self):

        if self.Karaktarsdrag['Stark'] <= 10:
            maximalTalighet = 10
        else:
            maximalTalighet = self.Karaktarsdrag['Stark']
        smartgrans = int(self.Karaktarsdrag['Stark']/2+0.5)
        korruptionstroskel = int(self.Karaktarsdrag['Viljestark']/2+0.5)
        permanentKorruption = 0

        return maximalTalighet,smartgrans,korruptionstroskel,permanentKorruption

    def visaKaraktarsdrag(self):
        for drag in list(self.Karaktarsdrag):
            print(drag+' '+str(self.Karaktarsdrag[drag]))

    def valjNyaFormagor(self,ERF,typ):
        ERFkvar = ERF
        Karaktarsdrag = self.Karaktarsdrag
        alt = self.formagAlternativ[:]

        MystiskaTraditioner = ['Häxkonster','Ordensmagi','Svartkonst','Teurgi']
        Narstridskonster = ['Sköldkamp','Naturlig krigare','Stångverkan','Tvillingattack','Tvåhandskraft']
        Avstandsstridskonster = ['Prickskytt','Stålkast']
        AlternativTraffsaker = ['Fint','Taktiker','Järnnäve','Sjätte sinne','Dominera']

        IckeKompatiblaFormagor = [MystiskaTraditioner, Narstridskonster,Avstandsstridskonster,AlternativTraffsaker]
        kbk = 'kbk'

        if typ == 'Mästare':

            while ERFkvar >= 10:
                alt1 = []
                alt2 = []
                alt3 = []
                for formaga in alt:
                    if formaga in self.Formagor:
                        if self.Formagor[formaga] == 'Gesäll':
                            alt1.append(formaga)
                        elif self.Formagor[formaga] == 'Novis':
                            alt2.append(formaga)
                    else:
                        alt3.append(formaga)
                span1 = len(alt1)
                span2 = len(alt2)
                span3 = len(alt3)
                if span1 != 0 and ERFkvar >= 30:
                    v = r.randrange(0,span1)
                    val = alt1[v]
                    if val in self.allaKrafter:
                        if self.tradition == '' or self.tradition == 'Svartkonst':
                            if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                self.permanentKorruption += 1
                                self.Formagor[val] = 'Mästare'
                                uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                self.formagAlternativ = uppdateradeAlternativ
                                uppdateradeAlternativ = [value for value in alt1 if value != val]
                                alt1 = uppdateradeAlternativ
                                ERFkvar = ERFkvar - 30
                        else:
                            if val in self.krafter:
                                if self.Formagor[self.tradition] == 'Mästare':
                                    self.Formagor[val] = 'Mästare'
                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                    self.formagAlternativ = uppdateradeAlternativ
                                    uppdateradeAlternativ = [value for value in alt1 if value != val]
                                    alt1 = uppdateradeAlternativ
                                    ERFkvar = ERFkvar - 30
                                else:
                                    kanske = r.random()
                                    if kanske > .7:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.permanentKorruption += 1
                                            self.Formagor[val] = 'Mästare'
                                            uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                            self.formagAlternativ = uppdateradeAlternativ
                                            uppdateradeAlternativ = [value for value in alt1 if value != val]
                                            alt1 = uppdateradeAlternativ
                                            ERFkvar = ERFkvar - 30
                                    else:
                                        pass
                            else:
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                    self.permanentKorruption += 1
                                    self.Formagor[val] = 'Mästare'
                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                    self.formagAlternativ = uppdateradeAlternativ
                                    uppdateradeAlternativ = [value for value in alt1 if value != val]
                                    alt1 = uppdateradeAlternativ
                                    ERFkvar = ERFkvar - 30
                    else:
                        if val == 'Ritualist':
                            if self.tradition == '' or self.tradition == 'Svartkonst':
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-3:
                                    self.valjRitual(3,'utanför')
                                    self.permanentKorruption += 3
                                else:
                                    kbk = 'nepp'
                            else:
                                mangd = 0
                                while mangd < 3:
                                    kanske = r.random()
                                    if kanske > 0.7:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.valjRitual(1,'utanför')
                                            self.permanentKorruption += 1
                                            mangd += 1
                                    else:
                                        self.valjRitual(1,'innanför')
                                        mangd += 1
                        if kbk == 'kbk':
                            self.Formagor[val] = 'Mästare'
                            uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                            self.formagAlternativ = uppdateradeAlternativ
                            uppdateradeAlternativ = [value for value in alt1 if value != val]
                            alt1 = uppdateradeAlternativ
                            ERFkvar = ERFkvar - 30
                elif span2 != 0 and ERFkvar >= 20:
                    v = r.randrange(0,span2)
                    val = alt2[v]
                    if val in self.allaKrafter:
                        if self.tradition == '' or self.tradition == 'Svartkonst':
                            if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                self.permanentKorruption += 1
                                self.Formagor[val] = 'Gesäll'
                                ERFkvar = ERFkvar - 20
                        else:
                            if val in self.krafter:
                                if self.Formagor[self.tradition] == 'Gesäll':
                                    self.Formagor[val] = 'Gesäll'
                                    ERFkvar = ERFkvar - 20
                                else:
                                    kanske = r.random()
                                    if kanske > .7:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.permanentKorruption += 1
                                            self.Formagor[val] = 'Gesäll'
                                            ERFkvar = ERFkvar - 20
                                    else:
                                        pass
                            else:
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                    self.permanentKorruption += 1
                                    self.Formagor[val] = 'Gesäll'
                                    ERFkvar = ERFkvar - 20
                    else:
                        if val == 'Ritualist':
                            if self.tradition == '' or self.tradition == 'Svartkonst':
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-2:
                                    self.valjRitual(2,'utanför')
                                    self.permanentKorruption += 2
                                else:
                                    kbk = 'nepp'
                            else:
                                mangd = 0
                                while mangd < 2:
                                    kanske = r.random()
                                    if kanske > 0.7:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.valjRitual(1,'utanför')
                                            self.permanentKorruption += 1
                                            mangd += 1
                                    else:
                                        self.valjRitual(2,'innanför')
                                        mangd += 1
                        if kbk == 'kbk':
                            self.Formagor[val] = 'Gesäll'
                            ERFkvar = ERFkvar - 20
                elif span3 != 0:
                    v = r.randrange(0,span3)
                    val = alt3[v]
                    if val == 'Mystisk kraft':
                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                            span = len(self.allaKrafter)
                            v = r.randrange(0,span)
                            val = self.allaKrafter[v]
                            self.permanentKorruption += 1
                            self.allaKrafter.remove(val)
                            for i in range(self.formagAlternativ.count('Mystisk kraft')):
                                self.formagAlternativ.append(val)
                                alt.append(val)
                        else:
                            kbk = 'nepp'
                    elif val == 'Ritualist':
                        if self.tradition == '' or self.tradition == 'Svartkonst':
                            if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                self.valjRitual(1,'utanför')
                                self.permanentKorruption += 1
                            else:
                                kbk = 'nepp'
                        else:
                            kanske = r.random()
                            if kanske > 0.7:
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                    self.valjRitual(1,'utanför')
                                    self.permanentKorruption += 1
                                else:
                                    kbk = 'nepp'
                            else:
                                self.valjRitual(1,'innanför')
                    elif val in MystiskaTraditioner:
                        self.mojligaKrafterOchRitualer(val)
                        self.tradition = val
                        for kraft in self.krafter:
                            for i in range(self.formagAlternativ.count('Mystisk kraft')):
                                self.formagAlternativ.append(kraft)
                                alt.append(kraft)
                    elif val in self.krafter and self.tradition == 'Svartkonst':
                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                            self.permanentKorruption += 1
                        else:
                            kbk = 'nepp'
                    else:
                        pass
                    if kbk == 'kbk':
                        self.Formagor[val] = 'Novis'
                        ERFkvar = ERFkvar - 10
                        for grupp in IckeKompatiblaFormagor:
                            if val in grupp:
                                grupp.remove(val)
                                for formaga in grupp:
                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != formaga]
                                    self.formagAlternativ = uppdateradeAlternativ
                                    uppdateradeAlternativ = [value for value in alt3 if value != formaga]
                                    alt3 = uppdateradeAlternativ
                else:
                    break

        elif typ == 'Gesäll':
            pass
        elif typ == 'Novis':
            pass
        else:
            while ERFkvar >= 10:
                span = len(alt)
                if span == 0:
                    break
                v = r.randrange(0,span)
                val = alt[v]
                if val in self.Formagor:
                    niva = self.Formagor[val]
                    if niva == 'Gesäll':
                        if ERFkvar >= 30:
                            if val in self.allaKrafter:
                                if self.tradition == '' or self.tradition == 'Svartkonst':
                                    if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                        self.permanentKorruption += 1
                                        self.Formagor[val] = 'Mästare'
                                        uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                        self.formagAlternativ = uppdateradeAlternativ
                                        uppdateradeAlternativ = [value for value in alt if value != val]
                                        alt = uppdateradeAlternativ
                                        ERFkvar = ERFkvar - 30
                                else:
                                    if val in self.krafter:
                                        if self.Formagor[self.tradition] == 'Mästare':
                                            self.Formagor[val] = 'Mästare'
                                            uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                            self.formagAlternativ = uppdateradeAlternativ
                                            uppdateradeAlternativ = [value for value in alt if value != val]
                                            alt = uppdateradeAlternativ
                                            ERFkvar = ERFkvar - 30
                                        else:
                                            kanske = r.random()
                                            if kanske > .7:
                                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                                    self.permanentKorruption += 1
                                                    self.Formagor[val] = 'Mästare'
                                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                                    self.formagAlternativ = uppdateradeAlternativ
                                                    uppdateradeAlternativ = [value for value in alt if value != val]
                                                    alt = uppdateradeAlternativ
                                                    ERFkvar = ERFkvar - 30
                                            else:
                                                pass
                                    else:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.permanentKorruption += 1
                                            self.Formagor[val] = 'Mästare'
                                            uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                            self.formagAlternativ = uppdateradeAlternativ
                                            uppdateradeAlternativ = [value for value in alt if value != val]
                                            alt = uppdateradeAlternativ
                                            ERFkvar = ERFkvar - 30
                            else:
                                if val == 'Ritualist':
                                    if self.tradition == '' or self.tradition == 'Svartkonst':
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-3:
                                            self.valjRitual(3,'utanför')
                                            self.permanentKorruption += 3
                                        else:
                                            kbk = 'nepp'
                                    else:
                                        mangd = 0
                                        while mangd < 3:
                                            kanske = r.random()
                                            if kanske > 0.7:
                                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                                    self.valjRitual(1,'utanför')
                                                    self.permanentKorruption += 1
                                                    mangd += 1
                                            else:
                                                self.valjRitual(1,'innanför')
                                                mangd += 1
                                if kbk == 'kbk':
                                    self.Formagor[val] = 'Mästare'
                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                    self.formagAlternativ = uppdateradeAlternativ
                                    uppdateradeAlternativ = [value for value in alt if value != val]
                                    alt = uppdateradeAlternativ
                                    ERFkvar = ERFkvar - 30
                        else:
                            uppdateradeAlternativ = [value for value in alt if value != val]
                            alt = uppdateradeAlternativ
                    else:
                        if ERFkvar >= 20:
                            if val in self.allaKrafter:
                                if self.tradition == '' or self.tradition == 'Svartkonst':
                                    if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                        self.permanentKorruption += 1
                                        self.Formagor[val] = 'Gesäll'
                                        ERFkvar = ERFkvar - 20
                                else:
                                    if val in self.krafter:
                                        if self.Formagor[self.tradition] == 'Gesäll':
                                            self.Formagor[val] = 'Gesäll'
                                            ERFkvar = ERFkvar - 20
                                        else:
                                            kanske = r.random()
                                            if kanske > .7:
                                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                                    self.permanentKorruption += 1
                                                    self.Formagor[val] = 'Gesäll'
                                                    ERFkvar = ERFkvar - 20
                                            else:
                                                pass
                                    else:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.permanentKorruption += 1
                                            self.Formagor[val] = 'Gesäll'
                                            ERFkvar = ERFkvar - 20
                            else:
                                if val == 'Ritualist':
                                    if self.tradition == '' or self.tradition == 'Svartkonst':
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-2:
                                            self.valjRitual(2,'utanför')
                                            self.permanentKorruption += 2
                                        else:
                                            kbk = 'nepp'
                                    else:
                                        mangd = 0
                                        while mangd < 2:
                                            kanske = r.random()
                                            if kanske > 0.7:
                                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                                    self.valjRitual(1,'utanför')
                                                    self.permanentKorruption += 1
                                                    mangd += 1
                                            else:
                                                self.valjRitual(1,'innanför')
                                                mangd += 1
                                if kbk == 'kbk':
                                    self.Formagor[val] = 'Gesäll'
                                    ERFkvar = ERFkvar - 20
                        else:
                            uppdateradeAlternativ = [value for value in alt if value != val]
                            alt = uppdateradeAlternativ
                else:
                    if val == 'Mystisk kraft':
                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                            span = len(self.allaKrafter)
                            v = r.randrange(0,span)
                            val = self.allaKrafter[v]
                            self.permanentKorruption += 1
                            self.allaKrafter.remove(val)
                            for i in range(self.formagAlternativ.count('Mystisk kraft')):
                                self.formagAlternativ.append(val)
                                alt.append(val)
                        else:
                            kbk = 'nepp'
                    elif val == 'Ritualist':
                        if self.tradition == '' or self.tradition == 'Svartkonst':
                            if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                self.valjRitual(1,'utanför')
                                self.permanentKorruption += 1
                            else:
                                kbk = 'nepp'
                        else:
                            kanske = r.random()
                            if kanske > 0.7:
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                    self.valjRitual(1,'utanför')
                                    self.permanentKorruption += 1
                                else:
                                    kbk = 'nepp'
                            else:
                                self.valjRitual(1,'innanför')
                    elif val in MystiskaTraditioner:
                        self.mojligaKrafterOchRitualer(val)
                        self.tradition = val
                        for kraft in self.krafter:
                            for i in range(self.formagAlternativ.count('Mystisk kraft')):
                                self.formagAlternativ.append(kraft)
                                alt.append(kraft)
                    elif val in self.krafter:
                        if self.tradition == 'Svartkonst':
                            if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                self.permanentKorruption += 1
                            else:
                                kbk = 'nepp'
                    else:
                        pass
                    if kbk == 'kbk':
                        self.Formagor[val] = 'Novis'
                        ERFkvar = ERFkvar - 10
                        for grupp in IckeKompatiblaFormagor:
                            if val in grupp:
                                grupp.remove(val)
                                for formaga in grupp:
                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != formaga]
                                    self.formagAlternativ = uppdateradeAlternativ
                                    uppdateradeAlternativ = [value for value in alt if value != formaga]
                                    alt = uppdateradeAlternativ

        self.ERFkvar = ERFkvar

    def gynnsammaFormagor(self):
        Diskret = ['Fint','Lönnstöt']
        Kvick = ['Akrobatik','Snabbdrag',]
        Listig = ['Alkemi','Giftbrukare','Lärd','Medicus','Monsterlärd',
        'Stryparkonst','Taktiker']
        Stark = ['Järnnäve','Sköldkamp','Ståndaktig']
        Traffsaker = ['Naturlig krigare','Prickskytt']
        Vaksam = ['Häxsyn','Sjätte sinne']
        Viljestark = ['Häxkonster','Häxsyn','Livvakt','Mystisk kraft',
        'Ordensmagi','Ritualist','Ståndaktig','Svartkonst','Teurgi',
        'Återhämtning']
        # Hur lösa de med magi?
        Overtygande = ['Dominera','Ledare']
        Allmann = ['Bärsärk','Exceptionellt Karaktärsdrag','Rustmästare',
        'Ryttarkonst','Stångverkan','Stålkast','Tvillingattack','Tvåhandskraft']

        Formagor = [Diskret,Kvick,Listig,Stark,Traffsaker,Vaksam,Viljestark,Overtygande,Allmann]

        alternativ1 = []
        i = -1
        for drag in list(self.Karaktarsdrag):
            i += 1
            if self.Karaktarsdrag[drag] == 15:
                for j in range(len(Formagor[i])):
                    alternativ1.append(Formagor[i][j])

        alternativ2 = []
        i = -1
        for drag in list(self.Karaktarsdrag):
            i += 1
            if self.Karaktarsdrag[drag] > 12 and self.Karaktarsdrag[drag] != 15:
                for j in range(len(Formagor[i])):
                    alternativ2.append(Formagor[i][j])

        alternativ3 = []
        i = -1
        for drag in list(self.Karaktarsdrag):
            i += 1
            if self.Karaktarsdrag[drag] > 10 and self.Karaktarsdrag[drag] < 13:
                for j in range(len(Formagor[i])):
                    alternativ3.append(Formagor[i][j])
        for formaga in Allmann:
            alternativ3.append(formaga)

        Alternativ = []
        for formaga in alternativ1:
            for i in range(9):
                Alternativ.append(formaga)

        for formaga in alternativ2:
            for i in range(3):
                Alternativ.append(formaga)
        for formaga in alternativ3:
            Alternativ.append(formaga)

        return Alternativ

    def levla(self,ERF,typ):
        ERFtotal = ERF + self.ERFkvar
        self.valjNyaFormagor(ERFtotal,typ)

        print('Dina förmågor är nu:')
        for formaga in list(self.Formagor):
            print(formaga.ljust(28)+str(self.Formagor[formaga]).rjust(10))

        self.sparaKaraktar()

    def sparaKaraktar(self):
        f = open(self.namn+'.txt', "w")
        f.write('Karaktär: '+self.namn+
        '\n'+'\n'+
        'Karaktärsdrag:'
        +'\n')
        f.close()

        for drag in list(self.Karaktarsdrag):
            f = open(self.namn+'.txt', "a")
            f.write(drag.ljust(11)+str(self.Karaktarsdrag[drag]).rjust(5)
            +'\n')
            f.close()

        f = open(self.namn+'.txt', "a")
        f.write('\n'+'Förmågor: '+
        '\n')
        f.close()

        for formaga in list(self.Formagor):
            f = open(self.namn+'.txt', "a")
            f.write(formaga.ljust(28)+str(self.Formagor[formaga]).rjust(10)
            +'\n')
            f.close()

        if len(self.valdaRitualer) > 0:
            f = open(self.namn+'.txt', "a")
            f.write('\n'+'Ritualer: '+
            '\n')
            f.close()

            for rit in self.valdaRitualer:
                f = open(self.namn+'.txt', "a")
                f.write(rit
                +'\n')
                f.close()

        f = open(self.namn+'.txt', "a")
        f.write('\n'+'Maximal tålighet: '+str(self.maximalTalighet)+
        '\n'+
        'Smärtgräns: '+str(self.smartgrans)+
        '\n'+
        'Korruptionströskel: '+str(self.korruptionstroskel)+
        '\n'+
        'Permanent korruption: '+str(self.permanentKorruption)
        )
        f.close()

    def mojligaKrafterOchRitualer(self,tradition):
        HaxkonstKraft = ['Bända vilja','Förhäxa','Hamnskifte',
        'Helbrägdagörelse','Larvböld','Naturens famn','Tvångsförvandling',
        'Vindpil','Ärva skada','Örtrankor']
        HaxkonstRitual = ['Andebesvärjelse','Bjära','Blodsband','Häxcirkel',
        'Låna best','Snabbväxt','Spådomskonst','Vyssja till ro','Vädervända']
        OrdensmagiKraft = ['Anatema','Brandvägg','Bända vilja','Förvirring',
        'Illusorisk korrigering','Obemärkt','Sannform','Svavelkaskad',
        'Tankekast','Viljelyft']
        OrdensmagiRitual = ['Askans berättelse','Bryta länk','Falsk terräng',
        'Flammande tjänare','Klärvoajans','Magisk cirkel','Sanktum',
        'Sjumilasteg','Själssten','Skenverk','Telepatiskt förhör']
        TeurgiKraft = ['Anatema','Helig aura','Helbrägdagörelse','Häxhammare',
        'Obemärkt','Sannform','Själens brännglas','Viljelyft','Välsignad sköld',
        'Ärva skada']
        TeurgiRitual = ['Dömande fjättrar','Exorcism','Helgande rit',
        'Kättarens spår','Offerrök','Orakelkonst','Renande eld','Skyddshelgon',
        'Syndabekännelse']
        ResterandeKrafter = ['Ohelig aura','Vandråp']
        ResterandeRitualer = ['Besätta','Byta skugga','Förslava','Vanhelgande rit']

        if tradition == 'Häxkonster':
            self.krafter = HaxkonstKraft
            self.ritualer = HaxkonstRitual
        elif tradition == 'Ordensmagi':
            self.krafter = OrdensmagiKraft
            self.ritualer = OrdensmagiRitual
        elif tradition == 'Teurgi':
            self.krafter = TeurgiKraft
            self.ritualer = TeurgiRitual
        elif tradition == 'Svartkonst':
            self.krafter = self.allaKrafter[:]
            self.ritualer = self.allaRitualer[:]
        else:
            allaKraft = [HaxkonstKraft, OrdensmagiKraft, TeurgiKraft, ResterandeKrafter]
            allaRit = [HaxkonstRitual, OrdensmagiRitual, TeurgiRitual,ResterandeRitualer ]
            Krafter = []
            Ritualer = []
            for i in range(len(allaRit)):
                tradKraft = allaKraft[i]
                tradRit =  allaRit[i]
                for kraft in tradKraft:
                    if kraft in Krafter:
                        pass
                    else:
                        Krafter.append(kraft)
                for ritual in tradRit:
                    if ritual in Ritualer:
                        pass
                    else:
                        Ritualer.append(ritual)
            self.allaKrafter = Krafter
            self.allaRitualer = Ritualer

    def valjRitual(self,antal,inom):

        if inom == 'innanför':
            alt = self.ritualer[:]

            for i in range(antal):
                span = len(alt)
                v = r.randrange(0,span)
                val = alt[v]

                alt.remove(val)

                self.ritualer.remove(val)
                self.allaRitualer.remove(val)
                self.valdaRitualer.append(val)
        else:
            alt = self.allaRitualer[:]

            for rit in self.ritualer:
                alt.remove(rit)
            for i in range(antal):
                span = len(alt)
                v = r.randrange(0,span)
                val = alt[v]

                alt.remove(val)

                self.allaRitualer.remove(val)
                self.valdaRitualer.append(val)

#------------------------------------------------------------------------------#

class Generator:
    def __init__(self):
        # Setup -----
        self.ERF = int(input('Hur mycket ERF har du att spendera? '))
        self.ERF_att_spendera = round(self.ERF/10)*10
        self.formagVal = ['Akrobatik','Alkemi','Bärsärk','Exceptionellt karaktärsdrag','Giftbrukare','Häxsyn','Livvakt','Lärd','Lönnstöt','Medicus','Monsterlärd','Prickskytt','Rustmästare','Ryttarkonst','Snabbdrag','Stryparkonst','Ståndaktig','Stålkast','Återhämtning','Belägringskonst','Brottning','Försåtsgillrare','Kanalisering','Oppurtunist','Runtatuering','Smideskonst','Snabbskytte','Tjyvknep','Trickskytte',
        'Dominera','Fint','Järnnäve','Ledare','Sjätte sinne','Taktiker',
        'Naturlig krigare','Sköldkamp','Stångverkan','Tvillingattack','Tvåhandskraft','Hammarrytm','Knivgöra','Närstridsskytte','Snärjande strid','Stavkamp','Stridsgisslare','Svärdshelgon','Yxkonstnär'
        ]
        self.formagor = {}
        self.karaktarsdrag = [5,5,5,5,5,5,5,5]

        # -----
        # Rasval -----
        sardrag = ['Förväxling','Robust','Överlevnadsinstinkt','Eonernas visdom']
        raser = ['Bortbyting','Rese','Svartalf','Alv','Ambrie','Barbar','Dvärg','Troll','Alvtagen människa','Vandöd']
        val = int(input('Vilken ras ska karaktären vara? Välj mellan siffrorna: (1) Bortbyting, (2) Rese, (3) Svartalf, (4) Alv, (5) Övrig, (6) spelar ingen roll! '))

        if val == 6:
            index = r.randrange(0,10)
            self.ras = raser[index]
            if index < 4:
                self.formagVal += sardrag[index]
        elif val == 5:
            index = r.randrange(4,10)
            self.ras = raser[index]
        else:
            self.ras = raser[val-1]
            self.formagVal += sardrag[val-1]
        # -----

        # Elityrke? -----
        if self.ERF > 90:
            elit = input('Du har tillräckligt med ERF för ett elityrke. Önskas ett elityrke? j/n ')
            if elit == 'j':
                elityrken = ['Järnsvuren','Templár','Vredesgardist','Artefaktmakare','Stavmagiker','Andebesvärjare','Blodvadare','Demonolog','Grönvävare','Illusionist','Inkvisitor','Mentalist','Nekromantiker','Pyromantiker','Själasörjare','Drottningspion','Gentlemannatjuv']
                val = int(input('Vilket elityrke ska karaktären ha? Välj mellan siffrorna: (1) Järnsvuren, (2) Templár, (3) Vredesgardist, (4) Artefaktmakare, (5) Stavmagiker, (6) Andebesvärjare, (7) Blodvadare, (8) Demonolog, (9) Grönvävare, (10) Illusionist, (11) Inkvisitor, (12) Mentalist, (13) Nekromantiker, (14) Pyromantiker, (15) Själasörjare, (16) Drottningspion, (17) Gentlemannatjuv, (18) spelar ingen roll! '))
                if val == 18:
                    index = r.randrange(0,17)
                    self.elityrke = elityrken[index]
                else:
                    self.elityrke = elityrken[val-1]
                elityrke(self.elityrke):
        # Därtill har det inverkan på sektionen "Mystiker" då denna kan behöva modifieras beroende på elityrke

        # Yrkesval -----
        yrken = ['Jägare','Krigare','Mystiker','Tjuv']
        yrkesformagor = ['Jaktinstinkt','Kraftprov','Stark gåva','Blixtsnabba reflexer']
        val = int(input('Vilket yrke ska karaktären ha? Välj mellan siffrorna: (1) Jägare, (2) Krigare, (3) Mystiker, (4) Tjuv, (5) spelar ingen roll! '))
        mystiker = 0

        if val == 5:
            index = r.randrange(0,4)
            self.yrke = yrken[index]
            yrkesformaga = yrkesformagor[index]
            if index == 2:
                mystiker = 1
                val2 = 8
        else:
            self.yrke = yrken[val-1]
            yrkesformaga = yrkesformagor[val-1]
            if val == 3:
                mystiker = 1
                val2 = int(input('Vilken tradition ska mystikern tillhöra? Välj mellan siffrorna: (1) Häxkonst, (2) Ordensmagi, (3) Teurgi, (4) Svartkonst, (5) Symbolism, (6) Trollsång, (7) Traditionslös mystiker, (8) spelar ingen roll! '))

        self.formagVal += yrkesformaga

        if mystiker == 1:
            mystiker()
        # -----

    def mystiker(self):
        traditioner = ['Häxkonster','Ordensmagi','Teurgi','Svartkonst','Symbolism','Trollsång','Traditionslös mystiker']

        HaxkonstKraft = ['Bända vilja','Förhäxa','Hamnskifte','Helbrägdagörelse','Larvböld','Naturens famn','Tvångsförvandling','Vindpil','Ärva skada','Örtrankor']
        HaxkonstRitual = ['Andebesvärjelse','Bjära','Blodsband','Häxcirkel','Låna best','Snabbväxt','Spådomskonst','Vyssja till ro','Vädervända','Förbannelse','Spårlös','Svart sympati','Ödestyngd']
        OrdensmagiKraft = ['Anatema','Brandvägg','Bända vilja','Förvirring','Illusorisk korrigering','Obemärkt','Sannform','Svavelkaskad','Tankekast','Viljelyft']
        OrdensmagiRitual = ['Askans berättelse','Bryta länk','Falsk terräng','Flammande tjänare','Klärvoajans','Magisk cirkel','Sanktum','Sjumilasteg','Själssten','Skenverk','Telepatiskt förhör','Falsk skepnad','Förhäxande landskap','Livsförlängning']
        TeurgiKraft = ['Anatema','Helig aura','Helbrägdagörelse','Häxhammare','Obemärkt','Sannform','Själens brännglas','Viljelyft','Välsignad sköld','Ärva skada']
        TeurgiRitual = ['Dömande fjättrar','Exorcism','Helgande rit','Kättarens spår','Offerrök','Orakelkonst','Renande eld','Skyddshelgon','Syndabekännelse','Sista smörjelse','Svart sympati']
        SvartkonstKraft = ['Bända vilja','Förhäxa','Larvböld','Ohelig aura','Vandråp','Förvisning','Mörkerblixt','Svart andedräkt','Vedergällning']
        SvartkonstRitual = ['Besätta','Byta skugga','Förslava','Vanhelgande rit','Frammana daemon','Förbannelse','Köttsmide','Phylakter','Själafälla','Svart sympati','Väcka vandöd']
        SymbolismKraft = ['Beskyddande runor','Dränerande glyf','Förblindande symbol','Fördrivande sigill']
        SymbolismRitual = ['Fjärrskrift','Formelfälla','Rista runtatuering','Runväktare']
        TrollsångKraft = ['Dansande vapen','Fanflykt','Förvirring','Hjältehymn','Kampsång','Vedergällning']
        TrollsångRitual = ['Sammanfoga','Återfinna']
        AllaKraft = ['Sfär','Bända vilja','Förhäxa','Hamnskifte','Helbrägdagörelse','Larvböld','Naturens famn','Tvångsförvandling','Vindpil','Ärva skada','Örtrankor','Anatema','Brandvägg','Förvirring','Illusorisk korrigering','Obemärkt','Sannform','Svavelkaskad','Tankekast','Viljelyft','Helig aura','Häxhammare','Själens brännglas','Välsignad sköld','Ohelig aura','Vandråp','Förvisning','Mörkerblixt','Svart andedräkt','Vedergällning','Dansande vapen','Fanflykt','Hjältehymn','Kampsång']
        AllaRitual = ['Andebesvärjelse','Bjära','Blodsband','Häxcirkel','Låna best','Snabbväxt','Spådomskonst','Vyssja till ro','Vädervända','Förbannelse','Spårlös','Svart sympati','Ödestyngd','Askans berättelse','Bryta länk','Falsk terräng','Flammande tjänare','Klärvoajans','Magisk cirkel','Sanktum','Sjumilasteg','Själssten','Skenverk','Telepatiskt förhör','Falsk skepnad','Förhäxande landskap','Livsförlängning','Dömande fjättrar','Exorcism','Helgande rit','Kättarens spår','Offerrök','Orakelkonst','Renande eld','Skyddshelgon','Syndabekännelse','Sista smörjelse','Besätta','Byta skugga','Förslava','Vanhelgande rit','Frammana daemon','Förbannelse','Köttsmide','Phylakter','Själafälla','Väcka vandöd','Sammanfoga','Återfinna']

        krafter = [HaxkonstKraft,OrdensmagiKraft,TeurgiKraft,SvartkonstKraft,SymbolismKraft,TrollsångKraft,AllaKraft]
        ritualer = [HaxkonstRitual,OrdensmagiRitual,TeurgiRitual,SvartkonstRitual,SymbolismRitual,TrollsångRitual,AllaRitual]
        if val2 == 8:
            index = r.randrange(0,7)
            self.tradition = traditioner[index]
            self.krafVal = krafter[index]
            self.ritualVal = ritualer[index]
        else:
            self.tradition = traditioner[val2-1]
            self.krafVal = krafter[val2-1]
            self.ritualVal = ritualer[val2-1]

        self.formagVal += self.kraftVal+'Ritualist'+self.tradition

        startVal = self.kraftVal+'Ritualist'
        start = r.randrange(0,len(startVal))
        val = startVal[start]

        if self.tradition == 'Traditionslös mystiker': # känns som att nånting saknas här
            if self.ERF_att_spendera >= 60:
                self.formagor[val] = 'Mästare'
                self.ERF_att_spendera += -60
                self.formagVal.remove(val)
            elif self.ERF_att_spendera >= 30:
                self.formagor[val] = 'Gesäll'
                self.ERF_att_spendera += -30
            else:
                self.formagor[val] = 'Novis'
                self.ERF_att_spendera += -10
        elif val in self.krafVal:
            if self.ERF_att_spendera >= 120:
                self.formagor[val] = 'Mästare'
                self.formagor[self.tradition] = 'Mästare'
                self.ERF_att_spendera += -120
                self.formagVal.remove(val)
                self.formagVal.remove(self.tradition)
            elif self.ERF_att_spendera >= 60:
                self.formagor[val] = 'Gesäll'
                self.formagor[self.tradition] = 'Gesäll'
                self.ERF_att_spendera += -60
            elif self.ERF_att_spendera >= 20:
                self.formagor[val] = 'Novis'
                self.formagor[self.tradition] = 'Novis'
                self.ERF_att_spendera += -20
            else:
                self.formagor[self.tradition] = 'Novis'
                self.ERF_att_spendera += -10
        else:
            if self.ERF_att_spendera >= 70:
                self.formagor[val] = 'Mästare'
                self.formagor[self.tradition] = 'Novis'
                self.ERF_att_spendera += -70
                self.formagVal.remove(val)
                self.formagVal.remove(self.tradition)
            elif self.ERF_att_spendera >= 40:
                self.formagor[val] = 'Gesäll'
                self.formagor[self.tradition] = 'Novis'
                self.ERF_att_spendera += -40
            elif self.ERF_att_spendera >= 20:
                self.formagor[val] = 'Novis'
                self.formagor[self.tradition] = 'Novis'
                self.ERF_att_spendera += -20
            else:
                self.formagor[self.tradition] = 'Novis'
                self.ERF_att_spendera += -10
        if val == 'Ritualist': #här kalla på funktion för antal och välja ritualer
            pass

    # om mystiker så ska första förmågvalet vara tradition och kraft/ritual - en specifik funktion för detta

    def mystiskKraft(self,kraft): #program används när mystiska krafter väljs
        pass

    def ritual(self,niva): #program för val av ritual
        pass

    def elityrke(self,yrke): # program används vid start då ett elityrke ska has
        pass





        #---------------------------------------------------------------------------------



        self.elityrkVal = ['Artefaktmakande','Bepansrad mystiker','Blodskamp','Manteldans',
        'Pyroteknik','Rörlig strid','Stavmagi']
        self.lastVal = ['Andeplåga','Eldsjäl','Illusionskopia','Livgivare','Purgatorium',
        'Sinnesstöt','Spökvandring','Stavprojektil','Teleportering','Törnemantel','Vild jakt']

        self.valAlternativ = self.sardragVal+self.formagVal+self.alternativKaraktarsdragVal+
        self.traditioinVal+self.krigsKonstVal+self.self.kraftVal
        if self.ERF > 90:
            self.valAlternativ += self.elityrkVal+self.lastVal+self.yrkVal
        elif self.ERF > 30:
            self.valAlternativ += self.yrkVal

        valjformaga()

    def valjformaga(self): # fortsätt koda här
        val = self.valAlternativ[r.randrange(0,len(self.valAlternativ))]

        if val in self.elityrkVal:
            elityrke(val) # fortsätt koda här
        elif val in self.lastVal:
            pass # fortsätt koda här
        elif val in self.yrkVal:
            pass # fortsätt koda här
        elif val in self.alternativKaraktarsdragVal:
            pass # fortsätt koda här
        elif val in self.kraftVal:
            pass # fortsätt koda här
        elif val == 'Ritualist':
            pass # fortsätt koda här
        elif val in self.traditioinVal:
            pass

        if self.ERF_att_spendera >= 60:
            niva = 'Mästare'
            self.ERF_att_spendera += -60
        elif self.ERF_att_spendera >= 30:
            niva = 'Gesäll'
            self.ERF_att_spendera += -30
        else:
            niva = 'Novis'
            self.ERF_att_spendera += -10

        self.formagval(val,niva) # fortsätt koda här

    def formagval(self,formaga,niva): # fortsätt koda här
        pass

    def elityrke(self,formaga): #fortsätt koda här
        yrken = {'Artefaktmakande':'Artefaktmakare','Bepansrad mystiker':'Templar',
        'Blodskamp':'Vredesgardist','Manteldans':'Gentlemannatjuv','Pyroteknik':'Drottningsspion',
        'Rörlig strid':'Järnsvuren','Stavmagi':'Stavmagiker'}
        yrke = yrken[formaga]
        if self.elityrke == yrke: # fortsätt här
            pass
        else:
            yrkeskrav = {'Artefaktmakare':['Lärd','Ritualist','Smideskonst',['Mystisk kraft']],
            'Templar':['Järnnäve','Rustmästare','Teurgi',['Häxhammare','Helig aura']],
            'Vredesgardist':['Järnnäve','Rustmästare','Återhämtning',['Sköldkamp','Tvillingattack']],
            'Gentlemannatjuv':['Akrobatik','Dominera','Försåtsgillrare',['Svärdshelgon','Tvillingattack']],
            'Drottningsspion':['Fint','Svärdshelgon','Tvillingattack',['Giftbrukare','Stryparkonst']],
            'Järnsvuren':['Lärd','Monsterlärd','Prickskytt',['Stångverkan','Tvillingattack']],
            'Stavmagiker':['Lärd','Stavkamp','Stångverkan',['Mystisk kraft']]}

            krav = yrkeskrav[yrke]

            masterPresent = 0
            present = []
            for i in range(0,3):
                if krav[i] in self.formagor:
                    if self.formagor[krav[i]] == 'Mästare':
                        masterPresent = 1
                    present += krav[i]
            for j in krav[-1]:
                if j in self.formagor:
                    if self.formagor[j] == 'Mästare':
                        masterPresent = 1
                present += j
                if j == 'Mystisk kraft':
                    for k in self.kraftVal:
                        if k in self.formagor:
                            if self.formagor[k] == 'Mästare':
                                masterPresent = 1
                        present += 'Mystisk kraft'

            if masterPresent == 0:


            alternativ = krav[-1]
            del krav[-1]

            if alternativ[0] == 'Mystisk kraft':
                kraft = self.kraftVal[r.randrange(0,len(self.kraftVal))]
                krav += kraft
            else:
                val = alternativ[r.randrange(0,len(alternativ))]
                krav += val

            master = krav[r.randrange(0,len(krav))]

            self.formagval(master,'Mästare')

            #fortsätt här

    def kraftval(self):


#------------------------------------------------------------------------------#

Generator()
