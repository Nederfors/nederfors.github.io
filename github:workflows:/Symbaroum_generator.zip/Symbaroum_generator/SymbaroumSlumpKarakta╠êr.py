"""
Hej och välkommen!

Med denna kod kan du skapa en slumpmässig rollspelskaraktär. En del information
får du direkt printad när koden körs men för all information om karaktären får du
titta i textdokumentet som koden skapar (dokumentet hittar du i samma mapp som
python-filen ligger i). Viktigt för att koden ska funka är att denna fil ligger
i samma mapp som "SymbaroumGenerator".

För att skapa en karaktär skriver du följande:

'namn på karaktär' = Karaktär('namn',startERF,dragTyp,formagTyp)

namn = Namnet på karaktären
startERF = Den mängd erfarenhetspoäng som karaktären ska börja med
dragTyp = Påverkar val av karaktärsdrag, kan ta emot tre olika alternativ:
    - 'specialist' = Skapar en karaktär med 15 i ett karaktärsdrag och fördelar
    slumpmässigt ut resterande poäng
    - 'minmax' = Skapar en karaktär med 15 och 14 i så många karaktärsdrag som
    möjligt på måfå
    - Lämnas det tomt eller skrivs något annat så fördelas poäng ut helt på måfå
formagTyp = Påverkar val av förmågor, kan ta emot två alternativ:
    - 'Mästare' = Skapar karaktär som i största möjliga mån väljer att gå till
    mästarnivå i förmågor den väljer. När ERF inte räcker väljs istället gesäll
    och därefter novis
    - Lämnas det tomt eller skrivs något annat så väljs förmågor helt på måfå

För att lämna ett område tomt skriv: ''

"""
#------------------------------------------------------------------------------#
# Rör inte detta!!!
import SymbaroumGenerator as S

#------------------------------------------------------------------------------#
# Fält för dig att skriva i!

Bob1 = S.Karaktar('Bob1',100,'','')
#Bob2 = Karaktar('Bob2',100,'','')


#------------------------------------------------------------------------------#
