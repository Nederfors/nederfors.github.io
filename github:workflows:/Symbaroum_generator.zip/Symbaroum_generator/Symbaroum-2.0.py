import random as r
import sys as s
import snoop

class Karaktar:
    def __init__(self,namn,ERF,dragTyp,formagTyp):
        self.namn = namn
        self.ERF = ERF
        self.ERFkvar = ERF
        self.Karaktarsdrag = self.skapaKaraktarsdrag(dragTyp)
        stats = self.ovrigaStats()
        self.maximalTalighet = stats[0]
        self.smartgrans = stats[1]
        self.korruptionstroskel = stats[2]
        self.permanentKorruption = stats[3]
        self.Formagor = {}
        self.formagAlternativ = self.gynnsammaFormagor()
        self.krafter = []
        self.ritualer = []
        self.valdaRitualer = []
        self.tradition = ''
        self.allaKrafter = []
        self.allaRitualer = []
        self.mojligaKrafterOchRitualer('ingen')
        self.valjNyaFormagor(ERF,formagTyp)

        print('Välkommen till äventryret '+self.namn+'!')
        print('Dina karaktärsdrag är:')
        for drag in list(self.Karaktarsdrag):
            print(drag.ljust(11)+str(self.Karaktarsdrag[drag]).rjust(5))
        print('')
        print('Dina första förmågor är:')
        for formaga in list(self.Formagor):
            print(formaga.ljust(28)+str(self.Formagor[formaga]).rjust(10))
        print('')

        self.sparaKaraktar()

    def skapaKaraktarsdrag(self,typ):
        Karaktarsdrag = {
        'Diskret':5,
        'Kvick':5,
        'Listig':5,
        'Stark':5,
        'Träffsäker':5,
        'Vaksam':5,
        'Viljestark':5,
        'Övertygande':5
        }

        if typ == 'specialist':
            T8 = r.randrange(0,8)
            Drag = list(Karaktarsdrag)
            drag = Drag[T8]
            Karaktarsdrag[drag] = 15
            Drag.remove(drag)
            for i in range(30):
                roll = 'not done'
                while roll != 'done':
                    T7 = r.randrange(0,7)
                    drag = Drag[T7]
                    if Karaktarsdrag[drag] == 14:
                        roll = 'not done'
                    else:
                        Karaktarsdrag[drag] += 1
                        roll = 'done'
        elif typ == 'minmax':
            T8 = r.randrange(0,8)
            Drag = list(Karaktarsdrag)
            drag = Drag[T8]
            Karaktarsdrag[drag] = 15
            Drag.remove(drag)
            for i in range(3):
                Ti = r.randrange(0,7-i)
                drag = Drag[Ti]
                Karaktarsdrag[drag] = 14
                Drag.remove(drag)
            T4 = r.randrange(0,4)
            drag = Drag[T4]
            Karaktarsdrag[drag] = 8
        else:
            for i in range(40):
                roll = 'not done'
                while roll != 'done':
                    T8 = r.randrange(0,8)
                    drag = list(Karaktarsdrag)[T8]
                    if Karaktarsdrag[drag] == 15:
                        roll = 'not done'
                    elif Karaktarsdrag[drag] == 14:
                        max = 'not reached'
                        for dragen in Karaktarsdrag:
                            if Karaktarsdrag[dragen] == 15:
                                max = 'reached'
                        if max == 'reached':
                            roll = 'not done'
                        else:
                            Karaktarsdrag[drag] += 1
                            roll = 'done'
                    else:
                        Karaktarsdrag[drag] += 1
                        roll = 'done'
        return Karaktarsdrag # Skapar karaktärsdragen

    def ovrigaStats(self):

        if self.Karaktarsdrag['Stark'] <= 10:
            maximalTalighet = 10
        else:
            maximalTalighet = self.Karaktarsdrag['Stark']
        smartgrans = int(self.Karaktarsdrag['Stark']/2+0.5)
        korruptionstroskel = int(self.Karaktarsdrag['Viljestark']/2+0.5)
        permanentKorruption = 0

        return maximalTalighet,smartgrans,korruptionstroskel,permanentKorruption

    def visaKaraktarsdrag(self):
        for drag in list(self.Karaktarsdrag):
            print(drag+' '+str(self.Karaktarsdrag[drag]))

    def valjNyaFormagor(self,ERF,typ):
        ERFkvar = ERF
        Karaktarsdrag = self.Karaktarsdrag
        alt = self.formagAlternativ[:]

        MystiskaTraditioner = ['Häxkonster','Ordensmagi','Svartkonst','Teurgi']
        Narstridskonster = ['Sköldkamp','Naturlig krigare','Stångverkan','Tvillingattack','Tvåhandskraft']
        Avstandsstridskonster = ['Prickskytt','Stålkast']
        AlternativTraffsaker = ['Fint','Taktiker','Järnnäve','Sjätte sinne','Dominera']

        IckeKompatiblaFormagor = [MystiskaTraditioner, Narstridskonster,Avstandsstridskonster,AlternativTraffsaker]
        kbk = 'kbk'

        if typ == 'Mästare':

            while ERFkvar >= 10:
                alt1 = []
                alt2 = []
                alt3 = []
                for formaga in alt:
                    if formaga in self.Formagor:
                        if self.Formagor[formaga] == 'Gesäll':
                            alt1.append(formaga)
                        elif self.Formagor[formaga] == 'Novis':
                            alt2.append(formaga)
                    else:
                        alt3.append(formaga)
                span1 = len(alt1)
                span2 = len(alt2)
                span3 = len(alt3)
                if span1 != 0 and ERFkvar >= 30:
                    v = r.randrange(0,span1)
                    val = alt1[v]
                    if val in self.allaKrafter:
                        if self.tradition == '' or self.tradition == 'Svartkonst':
                            if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                self.permanentKorruption += 1
                                self.Formagor[val] = 'Mästare'
                                uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                self.formagAlternativ = uppdateradeAlternativ
                                uppdateradeAlternativ = [value for value in alt1 if value != val]
                                alt1 = uppdateradeAlternativ
                                ERFkvar = ERFkvar - 30
                        else:
                            if val in self.krafter:
                                if self.Formagor[self.tradition] == 'Mästare':
                                    self.Formagor[val] = 'Mästare'
                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                    self.formagAlternativ = uppdateradeAlternativ
                                    uppdateradeAlternativ = [value for value in alt1 if value != val]
                                    alt1 = uppdateradeAlternativ
                                    ERFkvar = ERFkvar - 30
                                else:
                                    kanske = r.random()
                                    if kanske > .7:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.permanentKorruption += 1
                                            self.Formagor[val] = 'Mästare'
                                            uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                            self.formagAlternativ = uppdateradeAlternativ
                                            uppdateradeAlternativ = [value for value in alt1 if value != val]
                                            alt1 = uppdateradeAlternativ
                                            ERFkvar = ERFkvar - 30
                                    else:
                                        pass
                            else:
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                    self.permanentKorruption += 1
                                    self.Formagor[val] = 'Mästare'
                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                    self.formagAlternativ = uppdateradeAlternativ
                                    uppdateradeAlternativ = [value for value in alt1 if value != val]
                                    alt1 = uppdateradeAlternativ
                                    ERFkvar = ERFkvar - 30
                    else:
                        if val == 'Ritualist':
                            if self.tradition == '' or self.tradition == 'Svartkonst':
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-3:
                                    self.valjRitual(3,'utanför')
                                    self.permanentKorruption += 3
                                else:
                                    kbk = 'nepp'
                            else:
                                mangd = 0
                                while mangd < 3:
                                    kanske = r.random()
                                    if kanske > 0.7:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.valjRitual(1,'utanför')
                                            self.permanentKorruption += 1
                                            mangd += 1
                                    else:
                                        self.valjRitual(1,'innanför')
                                        mangd += 1
                        if kbk == 'kbk':
                            self.Formagor[val] = 'Mästare'
                            uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                            self.formagAlternativ = uppdateradeAlternativ
                            uppdateradeAlternativ = [value for value in alt1 if value != val]
                            alt1 = uppdateradeAlternativ
                            ERFkvar = ERFkvar - 30
                elif span2 != 0 and ERFkvar >= 20:
                    v = r.randrange(0,span2)
                    val = alt2[v]
                    if val in self.allaKrafter:
                        if self.tradition == '' or self.tradition == 'Svartkonst':
                            if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                self.permanentKorruption += 1
                                self.Formagor[val] = 'Gesäll'
                                ERFkvar = ERFkvar - 20
                        else:
                            if val in self.krafter:
                                if self.Formagor[self.tradition] == 'Gesäll':
                                    self.Formagor[val] = 'Gesäll'
                                    ERFkvar = ERFkvar - 20
                                else:
                                    kanske = r.random()
                                    if kanske > .7:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.permanentKorruption += 1
                                            self.Formagor[val] = 'Gesäll'
                                            ERFkvar = ERFkvar - 20
                                    else:
                                        pass
                            else:
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                    self.permanentKorruption += 1
                                    self.Formagor[val] = 'Gesäll'
                                    ERFkvar = ERFkvar - 20
                    else:
                        if val == 'Ritualist':
                            if self.tradition == '' or self.tradition == 'Svartkonst':
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-2:
                                    self.valjRitual(2,'utanför')
                                    self.permanentKorruption += 2
                                else:
                                    kbk = 'nepp'
                            else:
                                mangd = 0
                                while mangd < 2:
                                    kanske = r.random()
                                    if kanske > 0.7:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.valjRitual(1,'utanför')
                                            self.permanentKorruption += 1
                                            mangd += 1
                                    else:
                                        self.valjRitual(2,'innanför')
                                        mangd += 1
                        if kbk == 'kbk':
                            self.Formagor[val] = 'Gesäll'
                            ERFkvar = ERFkvar - 20
                elif span3 != 0:
                    v = r.randrange(0,span3)
                    val = alt3[v]
                    if val == 'Mystisk kraft':
                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                            span = len(self.allaKrafter)
                            v = r.randrange(0,span)
                            val = self.allaKrafter[v]
                            self.permanentKorruption += 1
                            self.allaKrafter.remove(val)
                            for i in range(self.formagAlternativ.count('Mystisk kraft')):
                                self.formagAlternativ.append(val)
                                alt.append(val)
                        else:
                            kbk = 'nepp'
                    elif val == 'Ritualist':
                        if self.tradition == '' or self.tradition == 'Svartkonst':
                            if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                self.valjRitual(1,'utanför')
                                self.permanentKorruption += 1
                            else:
                                kbk = 'nepp'
                        else:
                            kanske = r.random()
                            if kanske > 0.7:
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                    self.valjRitual(1,'utanför')
                                    self.permanentKorruption += 1
                                else:
                                    kbk = 'nepp'
                            else:
                                self.valjRitual(1,'innanför')
                    elif val in MystiskaTraditioner:
                        self.mojligaKrafterOchRitualer(val)
                        self.tradition = val
                        for kraft in self.krafter:
                            for i in range(self.formagAlternativ.count('Mystisk kraft')):
                                self.formagAlternativ.append(kraft)
                                alt.append(kraft)
                    elif val in self.krafter and self.tradition == 'Svartkonst':
                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                            self.permanentKorruption += 1
                        else:
                            kbk = 'nepp'
                    else:
                        pass
                    if kbk == 'kbk':
                        self.Formagor[val] = 'Novis'
                        ERFkvar = ERFkvar - 10
                        for grupp in IckeKompatiblaFormagor:
                            if val in grupp:
                                grupp.remove(val)
                                for formaga in grupp:
                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != formaga]
                                    self.formagAlternativ = uppdateradeAlternativ
                                    uppdateradeAlternativ = [value for value in alt3 if value != formaga]
                                    alt3 = uppdateradeAlternativ
                else:
                    break

        elif typ == 'Gesäll':
            pass
        elif typ == 'Novis':
            pass
        else:
            while ERFkvar >= 10:
                span = len(alt)
                if span == 0:
                    break
                v = r.randrange(0,span)
                val = alt[v]
                if val in self.Formagor:
                    niva = self.Formagor[val]
                    if niva == 'Gesäll':
                        if ERFkvar >= 30:
                            if val in self.allaKrafter:
                                if self.tradition == '' or self.tradition == 'Svartkonst':
                                    if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                        self.permanentKorruption += 1
                                        self.Formagor[val] = 'Mästare'
                                        uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                        self.formagAlternativ = uppdateradeAlternativ
                                        uppdateradeAlternativ = [value for value in alt if value != val]
                                        alt = uppdateradeAlternativ
                                        ERFkvar = ERFkvar - 30
                                else:
                                    if val in self.krafter:
                                        if self.Formagor[self.tradition] == 'Mästare':
                                            self.Formagor[val] = 'Mästare'
                                            uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                            self.formagAlternativ = uppdateradeAlternativ
                                            uppdateradeAlternativ = [value for value in alt if value != val]
                                            alt = uppdateradeAlternativ
                                            ERFkvar = ERFkvar - 30
                                        else:
                                            kanske = r.random()
                                            if kanske > .7:
                                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                                    self.permanentKorruption += 1
                                                    self.Formagor[val] = 'Mästare'
                                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                                    self.formagAlternativ = uppdateradeAlternativ
                                                    uppdateradeAlternativ = [value for value in alt if value != val]
                                                    alt = uppdateradeAlternativ
                                                    ERFkvar = ERFkvar - 30
                                            else:
                                                pass
                                    else:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.permanentKorruption += 1
                                            self.Formagor[val] = 'Mästare'
                                            uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                            self.formagAlternativ = uppdateradeAlternativ
                                            uppdateradeAlternativ = [value for value in alt if value != val]
                                            alt = uppdateradeAlternativ
                                            ERFkvar = ERFkvar - 30
                            else:
                                if val == 'Ritualist':
                                    if self.tradition == '' or self.tradition == 'Svartkonst':
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-3:
                                            self.valjRitual(3,'utanför')
                                            self.permanentKorruption += 3
                                        else:
                                            kbk = 'nepp'
                                    else:
                                        mangd = 0
                                        while mangd < 3:
                                            kanske = r.random()
                                            if kanske > 0.7:
                                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                                    self.valjRitual(1,'utanför')
                                                    self.permanentKorruption += 1
                                                    mangd += 1
                                            else:
                                                self.valjRitual(1,'innanför')
                                                mangd += 1
                                if kbk == 'kbk':
                                    self.Formagor[val] = 'Mästare'
                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != val]
                                    self.formagAlternativ = uppdateradeAlternativ
                                    uppdateradeAlternativ = [value for value in alt if value != val]
                                    alt = uppdateradeAlternativ
                                    ERFkvar = ERFkvar - 30
                        else:
                            uppdateradeAlternativ = [value for value in alt if value != val]
                            alt = uppdateradeAlternativ
                    else:
                        if ERFkvar >= 20:
                            if val in self.allaKrafter:
                                if self.tradition == '' or self.tradition == 'Svartkonst':
                                    if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                        self.permanentKorruption += 1
                                        self.Formagor[val] = 'Gesäll'
                                        ERFkvar = ERFkvar - 20
                                else:
                                    if val in self.krafter:
                                        if self.Formagor[self.tradition] == 'Gesäll':
                                            self.Formagor[val] = 'Gesäll'
                                            ERFkvar = ERFkvar - 20
                                        else:
                                            kanske = r.random()
                                            if kanske > .7:
                                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                                    self.permanentKorruption += 1
                                                    self.Formagor[val] = 'Gesäll'
                                                    ERFkvar = ERFkvar - 20
                                            else:
                                                pass
                                    else:
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                            self.permanentKorruption += 1
                                            self.Formagor[val] = 'Gesäll'
                                            ERFkvar = ERFkvar - 20
                            else:
                                if val == 'Ritualist':
                                    if self.tradition == '' or self.tradition == 'Svartkonst':
                                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-2:
                                            self.valjRitual(2,'utanför')
                                            self.permanentKorruption += 2
                                        else:
                                            kbk = 'nepp'
                                    else:
                                        mangd = 0
                                        while mangd < 2:
                                            kanske = r.random()
                                            if kanske > 0.7:
                                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                                    self.valjRitual(1,'utanför')
                                                    self.permanentKorruption += 1
                                                    mangd += 1
                                            else:
                                                self.valjRitual(1,'innanför')
                                                mangd += 1
                                if kbk == 'kbk':
                                    self.Formagor[val] = 'Gesäll'
                                    ERFkvar = ERFkvar - 20
                        else:
                            uppdateradeAlternativ = [value for value in alt if value != val]
                            alt = uppdateradeAlternativ
                else:
                    if val == 'Mystisk kraft':
                        if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                            span = len(self.allaKrafter)
                            v = r.randrange(0,span)
                            val = self.allaKrafter[v]
                            self.permanentKorruption += 1
                            self.allaKrafter.remove(val)
                            for i in range(self.formagAlternativ.count('Mystisk kraft')):
                                self.formagAlternativ.append(val)
                                alt.append(val)
                        else:
                            kbk = 'nepp'
                    elif val == 'Ritualist':
                        if self.tradition == '' or self.tradition == 'Svartkonst':
                            if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                self.valjRitual(1,'utanför')
                                self.permanentKorruption += 1
                            else:
                                kbk = 'nepp'
                        else:
                            kanske = r.random()
                            if kanske > 0.7:
                                if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                    self.valjRitual(1,'utanför')
                                    self.permanentKorruption += 1
                                else:
                                    kbk = 'nepp'
                            else:
                                self.valjRitual(1,'innanför')
                    elif val in MystiskaTraditioner:
                        self.mojligaKrafterOchRitualer(val)
                        self.tradition = val
                        for kraft in self.krafter:
                            for i in range(self.formagAlternativ.count('Mystisk kraft')):
                                self.formagAlternativ.append(kraft)
                                alt.append(kraft)
                    elif val in self.krafter:
                        if self.tradition == 'Svartkonst':
                            if self.permanentKorruption < self.Karaktarsdrag['Viljestark']-1:
                                self.permanentKorruption += 1
                            else:
                                kbk = 'nepp'
                    else:
                        pass
                    if kbk == 'kbk':
                        self.Formagor[val] = 'Novis'
                        ERFkvar = ERFkvar - 10
                        for grupp in IckeKompatiblaFormagor:
                            if val in grupp:
                                grupp.remove(val)
                                for formaga in grupp:
                                    uppdateradeAlternativ = [value for value in self.formagAlternativ if value != formaga]
                                    self.formagAlternativ = uppdateradeAlternativ
                                    uppdateradeAlternativ = [value for value in alt if value != formaga]
                                    alt = uppdateradeAlternativ

        self.ERFkvar = ERFkvar

    def gynnsammaFormagor(self):
        Diskret = ['Fint','Lönnstöt']
        Kvick = ['Akrobatik','Snabbdrag',]
        Listig = ['Alkemi','Giftbrukare','Lärd','Medicus','Monsterlärd',
        'Stryparkonst','Taktiker']
        Stark = ['Järnnäve','Sköldkamp','Ståndaktig']
        Traffsaker = ['Naturlig krigare','Prickskytt']
        Vaksam = ['Häxsyn','Sjätte sinne']
        Viljestark = ['Häxkonster','Häxsyn','Livvakt','Mystisk kraft',
        'Ordensmagi','Ritualist','Ståndaktig','Svartkonst','Teurgi',
        'Återhämtning']
        # Hur lösa de med magi?
        Overtygande = ['Dominera','Ledare']
        Allmann = ['Bärsärk','Exceptionellt Karaktärsdrag','Rustmästare',
        'Ryttarkonst','Stångverkan','Stålkast','Tvillingattack','Tvåhandskraft']

        Formagor = [Diskret,Kvick,Listig,Stark,Traffsaker,Vaksam,Viljestark,Overtygande,Allmann]

        alternativ1 = []
        i = -1
        for drag in list(self.Karaktarsdrag):
            i += 1
            if self.Karaktarsdrag[drag] == 15:
                for j in range(len(Formagor[i])):
                    alternativ1.append(Formagor[i][j])

        alternativ2 = []
        i = -1
        for drag in list(self.Karaktarsdrag):
            i += 1
            if self.Karaktarsdrag[drag] > 12 and self.Karaktarsdrag[drag] != 15:
                for j in range(len(Formagor[i])):
                    alternativ2.append(Formagor[i][j])

        alternativ3 = []
        i = -1
        for drag in list(self.Karaktarsdrag):
            i += 1
            if self.Karaktarsdrag[drag] > 10 and self.Karaktarsdrag[drag] < 13:
                for j in range(len(Formagor[i])):
                    alternativ3.append(Formagor[i][j])
        for formaga in Allmann:
            alternativ3.append(formaga)

        Alternativ = []
        for formaga in alternativ1:
            for i in range(9):
                Alternativ.append(formaga)

        for formaga in alternativ2:
            for i in range(3):
                Alternativ.append(formaga)
        for formaga in alternativ3:
            Alternativ.append(formaga)

        return Alternativ

    def levla(self,ERF,typ):
        ERFtotal = ERF + self.ERFkvar
        self.valjNyaFormagor(ERFtotal,typ)

        print('Dina förmågor är nu:')
        for formaga in list(self.Formagor):
            print(formaga.ljust(28)+str(self.Formagor[formaga]).rjust(10))

        self.sparaKaraktar()

    def sparaKaraktar(self):
        f = open(self.namn+'.txt', "w")
        f.write('Karaktär: '+self.namn+
        '\n'+'\n'+
        'Karaktärsdrag:'
        +'\n')
        f.close()

        for drag in list(self.Karaktarsdrag):
            f = open(self.namn+'.txt', "a")
            f.write(drag.ljust(11)+str(self.Karaktarsdrag[drag]).rjust(5)
            +'\n')
            f.close()

        f = open(self.namn+'.txt', "a")
        f.write('\n'+'Förmågor: '+
        '\n')
        f.close()

        for formaga in list(self.Formagor):
            f = open(self.namn+'.txt', "a")
            f.write(formaga.ljust(28)+str(self.Formagor[formaga]).rjust(10)
            +'\n')
            f.close()

        if len(self.valdaRitualer) > 0:
            f = open(self.namn+'.txt', "a")
            f.write('\n'+'Ritualer: '+
            '\n')
            f.close()

            for rit in self.valdaRitualer:
                f = open(self.namn+'.txt', "a")
                f.write(rit
                +'\n')
                f.close()

        f = open(self.namn+'.txt', "a")
        f.write('\n'+'Maximal tålighet: '+str(self.maximalTalighet)+
        '\n'+
        'Smärtgräns: '+str(self.smartgrans)+
        '\n'+
        'Korruptionströskel: '+str(self.korruptionstroskel)+
        '\n'+
        'Permanent korruption: '+str(self.permanentKorruption)
        )
        f.close()

    def mojligaKrafterOchRitualer(self,tradition):
        HaxkonstKraft = ['Bända vilja','Förhäxa','Hamnskifte',
        'Helbrägdagörelse','Larvböld','Naturens famn','Tvångsförvandling',
        'Vindpil','Ärva skada','Örtrankor']
        HaxkonstRitual = ['Andebesvärjelse','Bjära','Blodsband','Häxcirkel',
        'Låna best','Snabbväxt','Spådomskonst','Vyssja till ro','Vädervända']
        OrdensmagiKraft = ['Anatema','Brandvägg','Bända vilja','Förvirring',
        'Illusorisk korrigering','Obemärkt','Sannform','Svavelkaskad',
        'Tankekast','Viljelyft']
        OrdensmagiRitual = ['Askans berättelse','Bryta länk','Falsk terräng',
        'Flammande tjänare','Klärvoajans','Magisk cirkel','Sanktum',
        'Sjumilasteg','Själssten','Skenverk','Telepatiskt förhör']
        TeurgiKraft = ['Anatema','Helig aura','Helbrägdagörelse','Häxhammare',
        'Obemärkt','Sannform','Själens brännglas','Viljelyft','Välsignad sköld',
        'Ärva skada']
        TeurgiRitual = ['Dömande fjättrar','Exorcism','Helgande rit',
        'Kättarens spår','Offerrök','Orakelkonst','Renande eld','Skyddshelgon',
        'Syndabekännelse']
        ResterandeKrafter = ['Ohelig aura','Vandråp']
        ResterandeRitualer = ['Besätta','Byta skugga','Förslava','Vanhelgande rit']

        if tradition == 'Häxkonster':
            self.krafter = HaxkonstKraft
            self.ritualer = HaxkonstRitual
        elif tradition == 'Ordensmagi':
            self.krafter = OrdensmagiKraft
            self.ritualer = OrdensmagiRitual
        elif tradition == 'Teurgi':
            self.krafter = TeurgiKraft
            self.ritualer = TeurgiRitual
        elif tradition == 'Svartkonst':
            self.krafter = self.allaKrafter[:]
            self.ritualer = self.allaRitualer[:]
        else:
            allaKraft = [HaxkonstKraft, OrdensmagiKraft, TeurgiKraft, ResterandeKrafter]
            allaRit = [HaxkonstRitual, OrdensmagiRitual, TeurgiRitual,ResterandeRitualer ]
            Krafter = []
            Ritualer = []
            for i in range(len(allaRit)):
                tradKraft = allaKraft[i]
                tradRit =  allaRit[i]
                for kraft in tradKraft:
                    if kraft in Krafter:
                        pass
                    else:
                        Krafter.append(kraft)
                for ritual in tradRit:
                    if ritual in Ritualer:
                        pass
                    else:
                        Ritualer.append(ritual)
            self.allaKrafter = Krafter
            self.allaRitualer = Ritualer

    def valjRitual(self,antal,inom):

        if inom == 'innanför':
            alt = self.ritualer[:]

            for i in range(antal):
                span = len(alt)
                v = r.randrange(0,span)
                val = alt[v]

                alt.remove(val)

                self.ritualer.remove(val)
                self.allaRitualer.remove(val)
                self.valdaRitualer.append(val)
        else:
            alt = self.allaRitualer[:]

            for rit in self.ritualer:
                alt.remove(rit)
            for i in range(antal):
                span = len(alt)
                v = r.randrange(0,span)
                val = alt[v]

                alt.remove(val)

                self.allaRitualer.remove(val)
                self.valdaRitualer.append(val)

"""
Anteckningar
gör så att om mystisk kraft väljs så rullas vilken kraft utav alla som finns
Den väljs
en permanent korruption tas
den läggs till i listan av möjliga förmågor och ska då förekomma lika många gånger som 'mystisk kraft' gör
sen om en tradition väljs läggs möjliga krafter till, där varje kraft förekommer lika ofta som 'mystisk kraft' gjorde
lägg till att om en mystisk kraft väljs på gesäll eller mästarnivå så måste det kollas om den ingår i en tradition som spelaren har och därefter om den traditionen är på tillräcklig hög nivå, annars fås en korruption
kanske att det ska finnas sannolikhet att rulla om när en kraft tas som skulle ge korruption?
sen att den gör nåt liknande för ritualer

Lägg in möjlighet att välja novis/mästare som guide förförmågor

Lägg in yrke/arketyp
Lägg in släkte + särdrag
Lägg in skugga
Lägg in personlighet/mål
Lägg in utrustning
Spelarens handbok
"""

"""
['Andebesvärjelse', 'Bjära', 'Blodsband', 'Häxcirkel', 'Låna best', 'Snabbväxt',
 'Spådomskonst', 'Vyssja till ro', 'Vädervända', 'Askans berättelse', 'Bryta länk',
  'Falsk terräng', 'Flammande tjänare', 'Klärvoajans', 'Magisk cirkel', 'Sanktum',
   'Sjumilasteg', 'Själssten', 'Skenverk', 'Telepatiskt förhör', 'Dömande fjättrar',
    'Exorcism', 'Helgande rit', 'Kättarens spår', 'Offerrök', 'Orakelkonst',
     'Renande eld', 'Skyddshelgon', 'Syndabekännelse', 'Besätta', 'Byta skugga',
      'Förslava', 'Vanhelgande rit']

"""

#------------------------------------------------------------------------------#

if len(s.argv) > 3:
    typ = s.argv[3]
    if len(s.argv) > 4:
        niva = s.argv[4]
    else:
        niva = 'inget'
else:
    typ = 'inget'
    niva = 'inget'

Bob = Karaktar(s.argv[1],int(s.argv[2]),typ,niva)


#Bob.levla(30)

#------------------------------------------------------------------------------#
"""
Hej och välkommen!

Med denna kod kan du skapa en slumpmässig rollspelskaraktär. En del information
får du direkt printad när koden körs men för all information om karaktären får du
titta i textdokumentet som koden skapar (dokumentet hittar du i samma mapp som
python-filen ligger i).

För att skapa en karaktär skriver du följande:

'namn på karaktär' = Karaktär(namn,startERF,dragTyp,formagTyp)

namn = Namnet på karaktären
startERF = Den mängd erfarenhetspoäng som karaktären ska börja med
dragTyp = Påverkar val av karaktärsdrag, kan ta emot tre olika alternativ:
    - 'specialist' = Skapar en karaktär med 15 i ett karaktärsdrag och fördelar
    slumpmässigt ut resterande poäng
    - 'minmax' = Skapar en karaktär med 15 och 14 i så många karaktärsdrag som
    möjligt på måfå
    - Lämnas det tomt eller skrivs något annat så fördelas poäng ut helt på måfå
formagTyp = Påverkar val av förmågor, kan ta emot två alternativ:
    - 'Mästare' = Skapar karaktär som i största möjliga mån väljer att gå till
    mästarnivå i förmågor den väljer. När ERF inte räcker väljs istället gesäll
    och därefter novis
    - Lämnas det tomt eller skrivs något annat så väljs förmågor helt på måfå
"""
