#%% Importing packages
import PySimpleGUI as sg
import generater as g
#%% Interface settings

sg.LOOK_AND_FEEL_TABLE['MyCreatedTheme'] = {'BACKGROUND': 'blanched almond',
                                        'TEXT': 'Black',
                                        'INPUT': 'AntiqueWhite3',
                                        'TEXT_INPUT': 'sienna3',
                                        'SCROLL': 'Blue',
                                        'BUTTON': ('Black', 'AntiqueWhite3'),
                                        'PROGRESS': ('Brown', 'Brown'),
                                        'BORDER': 1, 'SLIDER_DEPTH': 0,
'PROGRESS_DEPTH': 0, }

sg.theme('MyCreatedTheme')

#%% Specification function
def specification(info):
    layout = [
    [sg.Text("Var god och lämna dina specifikationer. Fält lämnade tomma eller inkorrekt ifyllda resulterar i val på måfå.",font=('Times',20))],
    [sg.Text("Önskad arketyp?",font=('Times',20))],
    [sg.Text("j = Jägare, k = Krigare, m = Mystiker, t = Tjuv",font=('Times',15))],
    [sg.Input(key="-arketyp-",font=('Times',20))],
    [sg.Text("Önskat släkte?",font=('Times',20))],
    [sg.Text("a = Ambrie, ba = Barbar, bo = Bortbyting, r = Rese, s = Svartalf",font=('Times',15))],
    [sg.Input(key="-slakte-",font=('Times',20))],
    [sg.Text("Önskad tradition? (enbart relevant för mystiker)",font=('Times',20))],
    [sg.Text("h = Häxkonst, o = Ordensmagi, t = Teurgi, sv = Svartkonst, sy = Symbolism, t = Trollsång, 0 = Traditionslös",font=('Times',15))],
    [sg.Input(key="-tradition-",font=('Times',20))],
    #[sg.Button("Generera med för-/nackdelar",font=('Times',20))],
    [sg.Button("Generera utan för-/nackdelar",font=('Times',20))]
    ]

    window = sg.Window("Symbaroum karaktärsgenerator",layout)
    event, values = window.read()
    window.close()

    if event == "Generera utan för-/nackdelar":
        character = g.Character(info,values)

    return character
#%% Unspecified function
def unspecified(info):
    values = {'-arketyp-': '', '-slakte-': '', '-tradition-': ''}
    character = g.Character(info,values)
    return character
#%% Initiate
def initiate():
    layout = [
        [sg.Text("Välkommen till karaktärsgeneratorn!",font=('Times',50))],
        [sg.Text("Generatorn innehåller material från Symbaroums grundregelbok samt Spelarens handbok, med några inslag från monsterkodex.",font=('Times',25))],
        [sg.Text("Vad heter karaktären?",font=('Times',20))],
        [sg.Input(key="-namn-",font=('Times',20))],
        [sg.Text("Hur mycket erfarenhet har karaktären?",font=('Times',20))],
        [sg.Input(key="-ERF-",font=('Times',20))],
        [sg.Text("Hur vill du generera karaktären?",font=('Times',20))],
        [sg.Button("Med specifikationer",font=('Times',20))],
        #[sg.Button("Helt på måfå med för-/nackdelar",font=('Times',20))],
        [sg.Button("Helt på måfå utan för-/nackdelar",font=('Times',20))]
    ]

    # Create start window
    window = sg.Window("Symbaroum karaktärsgenerator",layout)
    event, values = window.read()
    window.close() 

    if event == "Med specifikationer":
        character = specification(values)
    elif event == "Helt på måfå utan för-/nackdelar" :
        character = unspecified(values)
    elif event == "Helt på måfå med för-/nackdelar" :
        pass
    else:
        pass

    return character
#%% Endpoint
def endpoint(character):
    pass

    # Fix this loop so that abilities get listed correctly - add so that if rituals are present will a ritual list also be printed + same for powers
    abilities = []
    for ability in list(character.abilities.items()):
        abilities.append([sg.Text(ability+" : "+character.abilities[ability],font=('Times',15))])

    layout = [
        [sg.Text("Här är din färdiga karaktär:",font=('Times',30))],
        [sg.Text("Namn: ",font=('Times',25))], #+namn
        [sg.Text("Erfarenhet: ",font=('Times',25))], #+ERF
        [sg.Text("Arketyp: ",font=('Times',25))], #+arketypen + tradition om mystiker
        [sg.Text("Släkte: ",font=('Times',20))], # +släktet
        [sg.Text("Maximal tålighet: ",font=('Times',20))], # +tålighet
        [sg.Text("Smärtgräns: ",font=('Times',20))], # +smärtgräns
        [sg.Text("Korruptionströskel: ",font=('Times',20))], # +korruptionströskel
        [sg.Text("Permanent korruption: ",font=('Times',20))], # +korruption
        
        [sg.Text("Karaktärsdrag:",font=('Times',20))], 
        [sg.Text("Diskret: ",font=('Times',15))], # +diskret
        [sg.Text("Kvick: ",font=('Times',15))], # +kvick
        [sg.Text("Listig: ",font=('Times',15))], # +listig
        [sg.Text("Stark: ",font=('Times',15))], # +stark
        [sg.Text("Träffsäker: ",font=('Times',15))], # +träffsäker
        [sg.Text("Vaksam: ",font=('Times',15))], # +vaksam
        [sg.Text("Viljestark: ",font=('Times',15))], # +viljestark
        [sg.Text("Övertygande: ",font=('Times',15))], # +övertygande

        [sg.Text("Förmågor:",font=('Times',20))], 
        abilities,

        [sg.Button("Spara och avsluta",font=('Times',20))],
        [sg.Button("Avsluta utan att spara",font=('Times',20))]
    ]

    window = sg.Window("Symbaroum karaktärsgenerator",layout)
    event, values = window.read()

    if event == "Spara och avsluta":
        pass
        f = open(character.name+'.txt', "w")
        f.write('Karaktär: '+character.name+
        '\n'+
        'Erfarenhet: '+character.ERF+
        '\n'+
        'Arketyp: '+character.archetype+
        '\n'+
        'Släkte: '+character.race+        
        '\n'+'\n'+
        'Maximal tålighet: '+str(character.MaxHP)+
        '\n'+
        'Smärtgräns: '+str(character.painlimit)+
        '\n'+
        'Korruptionströskel: '+str(character.corruptionlimit)+
        '\n'+
        'Permanent korruption: '+str(character.permanentcorruption)+
        '\n'+'\n'+
        'Karaktärsdrag:'
        +'\n')
        f.close()

        for score in list(character.abilityscore):
            f = open(character.name+'.txt', "a")
            f.write(score.ljust(11)+str(character.abilityscore[score]).rjust(5)
            +'\n')
            f.close()

        f = open(character.name+'.txt', "a")
        f.write('\n'+'Förmågor: '+
        '\n')
        f.close()

        for ability in list(character.abilities):
            f = open(character.namn+'.txt', "a")
            f.write(ability.ljust(28)+str(character.abilities[ability]).rjust(10)+
            '\n')
            f.close()

        if len(character.powers) > 0:
            f = open(character.name+'.txt', "a")
            f.write('\n'+'Mystiska krafter: '+
            '\n')
            f.close()

            for power in character.powers:
                f = open(character.name+'.txt', "a")
                f.write(power.ljust(28)+str(character.powers[power]).rjust(10)+
                '\n')
                f.close()

        if len(character.rituals) > 0:
            f = open(character.name+'.txt', "a")
            f.write('\n'+'Ritualer: '+
            '\n')
            f.close()

            for ritual in character.rituals:
                f = open(character.name+'.txt', "a")
                f.write(ritual+
                '\n')
                f.close()

        window.close() 
    elif event == "Avsluta utan att spara":
        window.close() 

#%% Interface start
character = initiate()
endpoint(character)