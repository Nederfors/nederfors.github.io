#%% Importing packages
import random as r
#%% Character class
class Character:
    def __init__(self,info1,info2):
        self.name = info1["-namn-"]
        self.ERF = int(info1["-ERF-"])
        self.archetype = info2['-arketyp-']
        self.race = info2['-slakte-']
        self.tradition = info2['-tradition-']
        self.abilitykey = '' #archetype,tradition,rest of the abilities '0ehjkmorsty'

        self.basicstart()

        self.MaxHP, self.painlimit, self.corruptionlimit, self.permanentcorruption = 0,0,0,0

        self.abilityscores = {'Diskret':5,'Kvick':5,'Listig':5,'Stark':5,
                              'Träffsäker':5,'Vaksam':5,'Viljestark':5,'Övertygande':5}
        self.abilities = {}
        self.powers = {}
        self.rituals = []

        self.abilityscoreleft = 40
        self.possibleabilites = []
        self.possiblepowers = []
        self.possiblerituals = []
        
        self.abilitiestochoose()
        if self.tradition == 'Mystiker':
            self.mysticgenerate()
        else:
            self.generate()

    def basicstart(self):
        self.name, self.ERF, self.archetype, self.race, self.tradition,self.abilitykey = basicstart(self.name, self.ERF, self.archetype, self.race, self.tradition)
    
    def abilitiestochoose(self):
        self.possibleabilites,self.possiblepowers,self.possiblerituals = abilitiestochoose(self.archetype,self.race,self.tradition)

    def generate(self):
        pass

    def mysticgenerate(self):
        pass

#%% Basic start
def basicstart(name, ERF, archetype, race, tradition):
    archetypes = {'j':'Jägare', 'k':'Krigare', 'm':'Mystiker', 't':'Tjuv'}
    races = {'a':'Ambrie', 'ba':'Barbar', 'bo':'Bortbyting', 'r':'Rese', 's':'Svartalf'}
    traditions = {"h":'Häxkonster', 'o':'Ordensmagi', 't':'Teurgi', 'sv':'Svartkonst', 'sy':'Symbolism', 't':'Trollsång', '0':'Traditionslös'}
    keys = {'Jägare':'a', 'Krigare':'b', 'Mystiker':'c', 'Tjuv':'d','Häxkonster':'e','Ordensmagi':'f','Teurgi':'g','Svartkonst':'h','Symbolism':'i','Trollsång':'j','Traditionslös':'0'}
    if name == '':
        name = 'Trashman'
    try:
        if int(ERF) < 50:
            ERF = 50
        else:
            ERF = int(ERF)
    except:
        ERF = 50
    try:
        archetype = archetypes[archetype]
    except:
        archetype = list(archetypes.values())[r.randrange(0,4)]
    try:
        race = races[race]
    except:
        race = list(races.values())[r.randrange(0,5)]
    if archetype == 'Mystiker':
        try:
            tradition = traditions[tradition]
        except:
            tradition = list(traditions.values())[r.randrange(0,7)]
    else:
        tradition = '0'
    
    abilitykey = keys[archetype]+keys[tradition]

    return name, ERF, archetype, race, tradition, abilitykey
#%% Abilities possible to choose
def abilitiestochoose(archetype,race,tradition):
    possibleabilites = ['Akrobatik','Snabbdrag', 'Alkemi','Försåtsgillrare','Lärd','Medicus','Monsterlärd',
                        'Smideskonst','Kanalisering','Runtatuering','Återhämtning','Pansarbrottning','Sköldkamp','Stavkamp',
                        'Trickskytt','Yxkonstnär','Belägringskonst','Bersärk','Brottning','Dominera', 'Exceptionellt karaktärsdrag',
                        'Fint','Giftbrukare','Hammarrytm','Häxsyn','Järnnäve','Knivgöra','Ledare',
                        'Livvakt','Lönnstöt','Naturlig krigare','Närstridsskytte','Opportunist','Piskkämpe','Prickskytt',
                        'Rustmästare','Ryttarkonst','Sjätte sinne','Snabbskytte','Snärjande strid','Stridsgisslare','Stryparkonst',
                        'Stålkast','Ståndaktig','Stångverkan','Svärdshelgon','Taktiker','Tjyvknep','Tvillingattack',
                        'Tvåhandsfiness','Tvåhandskraft'
                        ]
    lockedabilities = {'Bortbyting':'Förväxling','Rese':'Robust','Svartalf':'Överlevnadsinstinkt'}
    #lockedabilities = {'Jägare':'Jaktinstinkt','Krigare':'Kraftprov','Mystiker':'Stark gåva','Tjuv':'Blixtsnabba reflexer','Bortbyting':'Förväxling','Rese':'Robust','Svartalf':'Överlevnadsinstinkt'}
    #possibleabilites.append(lockedabilities[archetype])
    try:
        possibleabilites.append(lockedabilities[race])
    except:
        pass

    if archetype == 'Mystiker':
        traditionsandpowers= {'Häxkonster':['Bända vilja','Förhäxa','Hamnskifte','Helbrägdagörelse','Larvböld','Naturens famn','Tvångsförvandling','Vindpil','Ärva skada','Örtrankor'],
                              'Ordensmagi':['Bända vilja','Anatema','Brandvägg','Förvirring','Illusoisk korrigering','Obemärkt','Sannform','Svavelkaskad','Tankekast','Viljelyft'],
                              'Svartkonst':['Bända vilja','Förhäxa','Larvböld','Mörkerblixt','Ohelig aura','Svart andedräkt','Vandråp','Vedergällning'],
                              'Symbolism':['Beskyddande runor','Dränerande glyf','Förblindande symbol','Fördrivande sigill'],
                              'Teurgi':['Anatema','Helbrägdagörelse','Obemärkt','Sannform','Viljelyft','Ärva skada','Helig aura','Häxhammare','Själens brännglas','Välsignad sköld'],
                              'Trollsång':['Vedergällning','Dansande vapen','Fanflykt','Hjältehymn','Kampsång']}
        traditionsandrituals= {'Häxkonster':['Andebesvärjelse','Bjära','Blodsband','Förbannelse','Häxcirkel','Låna best','Snabbväxt','Spådomskonst','Spårlös','Svart sympati','Vyssja till ro','Vädervända','Åkallan','Ödestyngd'],
                              'Ordensmagi':['Askans berättelse','Bryta länk','Falsk skepnad','Falsk terräng','Flammande tjänare','Klärvojans','Livsförlängning','Magisk cirkel','Sanktum','Sjumilasteg','Själssten','Skenverk','Telepatiskt förhör'],
                              'Svartkonst':['Förbannelse','Svart sympati','Besätta','Byta skugga','Falskt liv','Förslava','Köttsmide','Phylakter','Själafälla','Vanhelgande rit','Väcka vandöd'],
                              'Symbolism':['Fjärrskrift','Formelfälla','Rista runtatuering','Runväktare'],
                              'Teurgi':['Svart sympati','Dömande fjättrar','Exorcism','Helgande rit','Kättarens spår','Offerrök','Orakelkonst','Renande eld','Sista smörjelse','Skyddshelgon','Syndabekännelse'],
                              'Trollsång':['Förseglande/Öppnande rit','Sammanfoga','Sjunga Världsorm','Återfinna']}
        try:
            possiblepowers = traditionsandpowers[tradition]
            possiblerituals = traditionsandrituals[tradition]
        except:
            possiblepowers = list(set(traditionsandpowers['Häxkonster']+traditionsandpowers['Ordensmagi']+traditionsandpowers['Svartkonst']+traditionsandpowers['Symbolism']+traditionsandpowers['Teurgi']+traditionsandpowers['Trollsång']))
            possiblerituals = list(set(traditionsandrituals['Häxkonster']+traditionsandrituals['Ordensmagi']+traditionsandrituals['Svartkonst']+traditionsandrituals['Symbolism']+traditionsandrituals['Teurgi']+traditionsandrituals['Trollsång']))

        possibleabilites.append('Ritualist')
        for i in range(len(possiblepowers)):
            possibleabilites.append('Mystisk kraft')
    
    else:
        possiblepowers = []
        possiblerituals = [] 

    return possibleabilites,possiblepowers,possiblerituals
#%% Generate
def generate(ERF,abilitykey,abilityscores,abilityscoreleft,possibleabilites,abilities):
    ek = 0
    abilityscoreabilities = {'Diskret':['Fint','Lönnstöt'],
                             'Kvick':['Akrobatik','Blixtsnabba reflexer','Brottning','Knivgöra','Rustmästare','Snabbdrag'],
                             'Listig':['Alkemi','Artefaktmakande','Försåtsgillrare','Giftbrukare','Lärd','Medicus','Monsterlärd','Smideskonst','Stryparkonst','Taktiker','Tjyvknep'],
                             'Stark':['Blodskamp','Brottning','Hammarrytm','Järnnäve','Kraftprov','Pansarbrottning','Sköldkamp','Snärjande strid','Ståndaktig','Tvåhandsfiness'],
                              'Träffsäker':['Prickskytt','Pyroteknik','Snärjande strid','Stavkamp','Trickskytt','Yxkonstnär'],
                              'Vaksam':['Häxsyn','Sjätte sinne'],
                              'Viljestark':['Häxsyn','Kanalisering','Runtatuering','Ståndaktig','Återhämtning'],
                              'Övertygande':['Dominera','Ledare'],
                              'Närstrid':['Belägringskonst','Bersärk','Blodskamp','Giftbrukare','Hammarrytm','Kraftprov','Lönnstöt','Manteldans','Monsterlärd','Naturlig krigare','Närstridsskytte','Opportunist',
                                          'Pansarbrottning','Piskkämpe','Runtatuering','Ryttarkonst','Rörlig strid','Sköldkamp','Snärjande strid','Stavkamp','Stridsgisslare','Stryparkonst','Stångverkan','Svärdshelgon',
                                          'Tjyvknep','Tvillingattack','Tvåhandsfiness','Tvåhandskraft','Yxkonstnär'],
                              'Avstånd':['Blodskamp','Giftbrukare','Jaktinstinkt','Monsterlärd','Närstridsskytte','Prickskytt','Pyroteknik','Runtatuering','Rörlig strid','Snabbskytte','Stålkast','Trickskytt'],
                              'Försvar':['Livvakt','Svärdshelgon']
                              }
    abilityincreases = 0
    increase = 10

    while ERF > 60:
        selection = possibleabilites[r.randrange(0,len(possibleabilites))]
        if selection == 'Exceptionellt karaktärsdrag':
            ek += 1
            abilities['Exceptionellt karaktärsdrag: nr'+str(ek)] = 'Mästare'
            if ek == 8:
                possibleabilites.remove(selection)
        else:
            abilities[selection] = 'Mästare'
            possibleabilites.remove(selection)
        ERF += -60
        abilitykey += getkey(selection)

        for i in range(0,len(abilityscoreabilities)):
            if selection in abilityscoreabilities[list(abilityscoreabilities.keys())[i]]:
                pass # do shit
                try:
                    abilityscores[list(abilityscoreabilities.keys())[i]] += increase
                except:
                    if list(abilityscoreabilities.keys())[i] == 'Närstrid':
                        pass # do shit
                    elif list(abilityscoreabilities.keys())[i] == 'Avstånd':
                        pass # do shit
                    else:
                        pass # do shit
                abilityincreases += 1
                abilityscoreleft += - increase
                del abilityscoreabilities[list(abilityscoreabilities.keys())[i]]
                if list(abilityscoreabilities.keys())[i] == 'Träffsäker':
                    pass # do shit Dominera, 
                    
                
                break #?
        
        # add part that removes increase in some ability scores depending on chosen ability
            # if a score is increased that makes some other abilities less viable remove those abilites
            # also remove the abilities connected to the no more increased scores
        # add part that removes abilities that do not match the chosen ability

                
        

        # add the abilityscore part and removing of abilities that do not work together with the chosen ability


    while ERF > 30:
        pass
    while ERF > 10:
        pass

    if ek > 0:
        abilityscores = addextrascore(ek,abilityscores,abilities)
       
#%% Extra scores
def addextrascore(ek,abilityscores,abilities):
    modified = []
    pointsperlevel = {'Mästare':3,'Gesäll':2,'Novis':1}

    abilityscore = list(abilityscores.keys())[list(abilityscores.values()).index(15)]
    abilityscores[abilityscore] += pointsperlevel[abilities['Exceptionellt karaktärsdrag: nr1']]
    modified.append(abilityscore)

    s = 14
    for i in range(ek-1):
        points = pointsperlevel[abilities['Exceptionellt karaktärsdrag: nr'+str(i+1)]]
        done = 0
        while done == 0:
            increasable = []
            for key in abilityscores.items():
                if abilityscores[key] == s and key not in modified:
                    increasable.append(key)
            if len(increasable) == 0:
                s += -1
            else:
                selection = increasable[r.randrange(0,len(increasable))]
                abilityscores[selection] += points
                modified.append(selection)
                done = 1

    return abilityscores


            


#%% Get keys for abilities
def getkey(ability):
    keys ={'Akrobatik':'k','Alkemi':'l','Belägringskonst':'m','Bersärk':'n','Brottning':'o','Dominera':'p','Exceptionellt karaktärsdrag':'q',
           'Fint':'r','Försåtsgillrare':'s','Giftbrukare':'t','Hammarrytm':'u','Häxsyn':'v','Järnnäve':'w','Kanalisering':'x',
           'Knivgöra':'y','Ledare':'z','Livvakt':'A','Lärd':'B','Lönnstöt':'C','Medicus':'D','Monsterlärd':'E',
           'Naturlig krigare':'F','Närstridsskytte':'G','Opportunist':'H','Pansarbrottning':'I','Piskkämpe':'J','Prickskytt':'K','Runtatuering':'L',
           'Rustmästare':'M','Ryttarkonst':'N','Sjätte sinne':'O','Sköldkamp':'P','Smideskonst':'Q','Snabbdrag':'R','Snabbskytte':'S',
           'Snärjande strid':'T','Stavkamp':'U','Stridsgisslare':'V','Stryparkonst':'W','Stålkast':'X','Ståndaktig':'Y','Stångverkan':'Z',
           'Svärdshelgon':'1','Taktiker':'2','Tjyvknep':'3','Trickskytt':'4','Tvillingattack':'5','Tvåhandsfiness':'6','Tvåhandskraft':'7',
           'Yxkonstnär':'8','Återhämtning':'9'
           }
    return keys[ability]
#%% Dataframe concept
formagor_och_krafter_och_särdrag = ['Akrobatik','Alkemi', 'Artefaktmakande','Belägringskonst','Bepansrad mystiker','Bersärk',
                                    'Blixtsnabba reflexer','Blodskamp','Brottning','Dominera',
                                    'Exceptionellt karaktärsdrag','Fint','Försåtsgillrare','Giftbrukare','Hammarrytm',
                                    'Häxkonster','Häxsyn','Jaktinstinkt','Järnnäve','Kanalisering',
                                    'Knivgöra','Kraftprov','Ledare','Livvakt','Lärd',
                                    'Lönnstöt','Manteldans','Medicus','Monsterlärd','Mystisk kraft',
                                    'Naturlig krigare','Närstridsskytte','Opportunist','Ordensmagi','Pansarbrottning',
                                    'Piskkämpe','Prickskytt','Pyroteknik','Ritualist','Runtatuering',
                                    'Rustmästare','Ryttarkonst','Rörlig strid','Sjätte sinne','Sköldkamp',
                                    'Smideskonst','Snabbdrag','Snabbskytte','Snärjande strid','Stark gåva',
                                    'Stavkamp','Stavmagi','Stridsgisslare','Stryparkonst','Stålkast',
                                    'Ståndaktig','Stångverkan','Svartkonst','Svärdshelgon','Symbolism',
                                    'Taktiker','Teurgi','Tjyvknep','Trickskytt','Trollsång',
                                    'Tvillingattack','Tvåhandsfiness','Tvåhandskraft','Yxkonstnär','Återhämtning',
                                    
                                    'Anatema','Andeplåga','Beskyddande runor','Brandvägg','Bända vilja',
                                    'Dansande vapen','Dränerande glyf','Eldsjäl','Fanflykt','Förblindande symbol',
                                    'Fördrivande sigill','Förhäxa','Förvirring','Förvisning','Hamnskifte',
                                    'Helbrägdagörelse','Helig aura','Hjältehymn','Häxhammare','Illusionskopia',
                                    'Illusoisk korrigering','Kampsång','Larvböld','Livgivare','Mörkerblixt',
                                    'Naturens famn','Obemärkt','Ohelig aura','Purgatorium','Sannform',
                                    'Sfär','Sinnesstöt','Själens brännglas','Spökvandring','Stavprojektil',
                                    'Svart andedräkt','Svavelkaskad','Tankekast','Teleportering','Tvångsförvandling',
                                    'Törnemantel','Vandråp','Vedergällning','Vild jakt','Viljelyft',
                                    'Vindpil','Välsignad sköld','Ärva skada','Örtrankor',

                                    'Eonernas visdom','Förväxling','Jordnära','Robust','Överlevnadsinstinkt'
                                    ]
row = ['Förmåga','Novis','Gersäll','Mästare']
niva = ['Relaterat karaktärsdrag','Karaktärsdrag som ej passar','Närstrid?','Avstånd?','Strid?','Försvar?','Förmågor som inte matchar']

akrobatik = ['Akrobatik',[['Kvick'],'-',0,0,0,0,{'-'}],[['Kvick'],'-',0,0,0,0,{'-'}],[['Kvick'],['-'],0,0,0,0,{'-'}]]
alkemi = ['Alkemi',[['Listig'],'-',0,0,0,0,{'-'}],[['Listig'],'-',0,0,0,0,{'-'}],[['Listig'],'-',0,0,0,0,{'-'}]]
artefaktmakande = ['Artefaktmakande',[['Listig'],'-',0,0,0,0,{'-'}],[['Listig'],'-',0,0,0,0,{'-'}],[['Listig'],'-',0,0,0,0,{'-'}]]
belägringskonst = ['Belägringskonst',[['-'],'-',0,1,0,0,{'-'}],[['-'],'-',0,1,0,0,{'-'}],[['-'],'-',0,1,0,0,{'-'}]]
bepansrad_mystiker = ['Bepansrad mystiker',[['-'],'-',0,0,0,0,{'-'}],[['-'],'-',0,0,0,0,{'-'}],[['-'],'-',0,0,0,0,{'-'}]]
bersärk = ['Bersärk',[['-'],'-',1,0,0,0,{'Fint':1}],[['-'],'-',1,0,0,0,{'Fint':1}],[['-'],'-',1,0,0,0,{'Fint':1}]]
blixtsnabba_reflexer = ['Blixtsnabba reflexer',[['-'],'-',0,0,0,0,{'-'}],[['-'],'-',0,0,0,1,{'-'}],[['Kvick','Vaksam'],'-',0,0,0,1,{'-'}]]
blodskamp = ['Blodskamp',[['-'],'-',1,0,0,0,{'-'}],[['-'],'-',1,0,0,0,{'-'}],[['-'],'-',1,0,0,0,{'-'}]]
brottning = ['Brottning',[['Stark'],'-',1,0,0,0,{'-'}],[['Stark','Kvick'],'-',1,0,0,1,{'-'}],[['Stark','Kvick'],'-',1,0,0,0,{'-'}]]
dominera = ['Dominera',[['Övertygande'],'Träffsäker',0,0,0,0,{'Fint':1,'Järnnäve':1,'Knivgöra':1,'Taktiker':3}],[['Övertygande'],'Träffsäker',0,0,0,0,{'Fint':1,'Järnnäve':1,'Knivgöra':1,'Taktiker':3}],[['Övertygande'],'Träffsäker',0,0,0,0,{'Fint':1,'Järnnäve':1,'Knivgöra':1,'Taktiker':3}]]
exceptionellt_karaktärsdrag = ['Exceptionellt karaktärsdrag',[['-'],'-',0,0,0,0,{'-'}],[['-'],'-',0,0,0,0,{'-'}],[['-'],'-',0,0,0,0,{'-'}]]
fint = ['Fint',[['Diskret'],'Träffsäker',0,0,0,0,{'Dominera':1,'Järnnäve':1,'Knivgöra':1,'Taktiker':3}],[['Diskret'],'Kvick',0,0,0,0,{'Dominera':1,'Järnnäve':1,'Knivgöra':1,'Taktiker':2,'Sjätte sinne':2}],[['Diskret'],'Kvick',0,0,0,0,{'Dominera':1,'Järnnäve':1,'Knivgöra':1,'Taktiker':2,'Sjätte sinne':2}]]
försåtsgillrare = ['Försåtsgillrare',[['Listig'],'-',0,0,0,0,{'-'}],[['Listig'],'-',0,0,0,0,{'-'}],[['Listig'],'-',0,0,0,0,{'-'}]]
giftbrukare = ['Giftbrukare',[['Listig'],'-',0,0,1,0,{'-'}],[['Listig'],'-',0,0,1,0,{'-'}],[['Listig'],'-',0,0,1,0,{'Naturlig krigare':1}]]
hammarrytm = ['Hammarrytm',]




novis = [['Stark'],'-',1,0,0,0,{'-'}]
gesäll = [['Diskret'],'Kvick',0,0,0,0,{'Dominera':1,'Järnnäve':1,'Knivgöra':1,'Taktiker':2,'Sjätte sinne':2}]
mästare = [['Stark'],'-',1,0,0,0,{'Knivgöra':1,'Piskkämpe':1}]


#%% Garbage?
# This will be actual generater code
"""
Specifikationer:
- Arketyp
- Karaktärsdragprio?
- Släkte
- Förmågeprio?
- Tradition
- Kraftprio?
- För-/nackdelar ja/nej

För/nackdel när måfå
- Randomisera nackdelar
    - Randomisera antal: 0-4 st
    - Randomisera val av nackdelar
    - Lägg till extra erf i potten
    - Sätt prio/antiprio på karaktärsdrag
    - Modifiera fördelpott
- Randomisera fördelar
    - Randomisera antal: 0-20% av total erf
    - Randomisera val av fördelar
    - Dra bort erf från pott
    - Sätt prio på karaktärsdrag
- Avgör om blodsband/mörkt blod är med --> lägg in i förmågpott
- Gå vidare till förmågor
- Om det finns 5 erf kvar efter förmågor --> välj en till fördel på måfå (baserat på karaktärsdrag)

"""

"""
Pseudo for choosing:
- starta med alla förmågor (utom elit och de specifika för arketyp/släkte som karaktär inte har)
- spara 5 poäng för försvar
- när en förmåga väljs första gången ska den kolla:
    if förmåga in dictionary:
        karaktärsdrag = dictionary[förmåga]
        plocka bort karaktärsdrag som value på de förmågor som finns kvar
        plocka bort förmågor med 0 i dictionary
        maxa karaktärsdrag och ta bort poäng från pott


"""


kvick = ['Akrobatik','Snabbdrag']
listig = ['Alkemi','Försåtsgillrare','Lärd','Medicus','Monsterlärd','Smideskonst','Artefaktmakande']
viljestark = ['Kanalisering','Runtatuering','Återhämtning']
stark = ['Pansarbrottning','Sköldkamp']
träffsäker = ['Stavkamp','Trickskytt','Yxkonstnär']

elite = ['Artefaktmakande','Bepansrad mystiker','Blodskamp','Manteldans','Pyroteknik','Rörlig strid','Stavmagi']
attack = ['Belägringskonst','Bersärk']
archetypedependent = ['Blixtsnabba reflexer','Jaktinstinkt','Kraftprov','Mystisk kraft','Ritualist','Stark gåva']
traditions = ['Häxkonster','Ordensmagi','Svartkonst','Symbolism','Teurgi','Trollsång']
"""
Släkten
Förväxling - viljestark, diskret
Robust - attack
Överlevnadsinstinkt


Artefaktmakande - listig, elit
Blixtsnabba reflexer - tjuv, kvick
Blodskamp - elit, (stark)
Brottning - stark, kvick
Dominera - övertygande, anti-träffsäker
Exceptionellt karaktärsdrag
Fint - diskret, anti-träffsäker, anti-kvick
Giftbrukare - listig, attack
Hammarrytm - stark, attack
Häxsyn - vaksam, (viljestark)

Jaktinstinkt - jägare, attack

Järnnäve - stark, anti-träffsäker
Knivgöra - kvick, anti-träffsäker

Kraftprov - krigare, (stark)

Ledare - övertygande, anti-viljestark
Livvakt - viljestark, försvar
Lönnstöt - (diskret), attack

Manteldans - elit, attack

Naturlig krigare - attack
Närstridsskytte - attack
Opportunist - attack
Piskkämpe - attack
Prickskytt - attack

Pyroteknik - elit, träffsäker

Rustmästare - 
Ryttarkonst - attack

Rörlig strid - elit, attack

Sjätte sinne - vaksam, anti-träffsäker, anti-kvick
Snabbskytte - attack
Snärjande strid - träffsäker, stark

Stark gåva - viljestark, mystiker
Stavmagi - elit, (tradition)

Stridsgisslare - attack
Stryparkonst - listig, attack
Stålkast - attack
Ståndaktig - stark, viljestark
Stångverkan - attack
Svärdshelgon - attack, försvar
Taktiker - listig, anti-kvick, anti-träffsäker
Tjyvknep - (träffsäker), listig
Tvillingattack - attack
Tvåhandsfiness - stark, attack
Tvåhandskraft - attack
"""

"""
Powers
Andeplåga - elit
Bända vilja
Förhäxa
Hamnskifte - attack
Helbrägdagörelse
Larvböld
Naturens famn
Tvångsförvandling
Törnemantel - elit
Vild jakt - elit
Vindpil
Ärva skada - stark
Örtrankor

Anatema
Brandvägg
Förvirring
Illusoisk korrigering
Obemärkt
Sannform
Svavelkaskad
Tankekast
Viljelyft
Eldsjäl - elit
Tankekast - elit
Illusionskopia - elit

Mörkerblixt
Ohelig aura
Svart andedräkt
Vandråp
Vedergällning
Teleportering - elit
Spökvandring - elit
Förvisning - elit
andeplåga - elit

Beskyddande runor
Dränerande glyf
Förblindande symbol
Fördrivande sigill

Helig aura
Häxhammare
Livgivare - elit
Purgatorium - elit
Själens brännglas
Välsignad sköld

Dansande vapen
Fanflykt
Hjältehymn
Kampsång
"""

"""
Rituals
Andebesvärjelse
Bjära
Blodsband
Förbannelse
Hjärtebest - elit
Häxcirkel
Levande fästning -elit
Låna best
Snabbväxt
Spådomskonst
Spårlös
Svart sympati
Vyssja till ro
Vädervända
Åkallan
Ödestyngd
Dödsspådom - elit

Askans berättelse
Bryta länk
Falsk skepnad
Falsk terräng
Flammande tjänare
Förhäxande landskap - elit
Klärvojans
Livsförlängning
Magisk cirkel
Sanktum
Sjumilasteg
Själssten
Skenverk
Telepatiskt förhör
Fata morgana - elit
Formeltunnel - elit
Tvillingtjänare - elit

Besätta
Byta skugga
Dödsriddare - elit
Falskt liv
Frammana daemon - elit
Förslava
Köttsmide
Phylakter
Själafälla
Tjänardaemon - elit
Vanhelgande rit
Väcka vandöd

Fjärrskrift
Formelfälla
Rista runtatuering
Runväktare

Botgöring - elit
Dömande fjättrar
Exorcism
Helgande rit
Kättarens spår
Offerrök
Orakelkonst
Renande eld
Sista smörjelse
Skyddshelgon
Syndabekännelse
Syndarblick - elit

Förseglande/Öppnande rit
Sammanfoga
Sjunga Världsorm
Återfinna
"""

#%% Keys
""" Keys
'Jägare':'a', 
'Krigare':'b', 
'Mystiker':'c', 
'Tjuv':'d'
'Häxkonster':'e',
'Ordensmagi':'f',
'Teurgi':'g',
'Svartkonst':'h',
'Symbolism':'i',
'Trollsång':'j',
'Traditionslös':'0
['Akrobatik',   k
'Alkemi',   l
'Belägringskonst',  m
'Bersärk',  n
'Brottning' o
,'Dominera',    p
 'Exceptionellt karaktärsdrag', q
 'Fint',    r
'Försåtsgillrare',  s
'Giftbrukare'   t
,'Hammarrytm',  u
'Häxsyn',   v
'Järnnäve'  w
'Kanalisering'' x
'Knivgöra'  y
Ledare'     z
'Livvakt',  A
Lärd'       B
'Lönnstöt', C
,'Medicus', D
'Monsterlärd',  E
'Naturlig krigare', F
'Närstridsskytte',  G
'Opportunist',  H
,'Pansarbrottning'  I
'Piskkämpe',    J
'Prickskytt',   K
'Runtatuering'  L
Rustmästare',   M
'Ryttarkonst'   N
,'Sjätte sinne',    O
,'Sköldkamp',   P
Smideskonst',   Q
'Snabbdrag',    R
'Snabbskytte',  S
'Snärjande strid'   T
'Stavkamp',     U
,'Stridsgisslare',  V
'Stryparkonst', W
'Stålkast',     X
'Ståndaktig',   Y
'Stångverkan',  Z
'Svärdshelgon', 1
Taktiker',      2
'Tjyvknep',     3
'Trickskytt',   4
''Tvillingattack',  5
Tvåhandsfiness','   6
Tvåhandskraft'  7
'Yxkonstnär',   8
'Återhämtning'  9

"""

#%% Testing cell
dict = {'a':[2,2,3],'b':3,'c':2}
del dict['a']
dict

#%%
len(formagor_och_krafter_och_särdrag)
# %%
